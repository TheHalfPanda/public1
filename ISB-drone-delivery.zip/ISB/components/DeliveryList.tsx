"use client";

import { Delivery } from "@/lib/types";
import { motion } from "framer-motion";

interface DeliveryListProps {
  deliveries: Delivery[];
  onSelectDelivery: (delivery: Delivery) => void;
  selectedDeliveryId?: string;
}

const statusConfig = {
  queued: { label: "QUEUED", color: "text-gray-400", bg: "bg-gray-400/10" },
  assigned: { label: "ASSIGNED", color: "text-blue-400", bg: "bg-blue-400/10" },
  in_flight: { label: "IN FLIGHT", color: "text-aerly-accent", bg: "bg-aerly-accent/10" },
  delivered: { label: "DELIVERED", color: "text-aerly-success", bg: "bg-aerly-success/10" },
  failed: { label: "FAILED", color: "text-aerly-danger", bg: "bg-aerly-danger/10" },
};

export default function DeliveryList({
  deliveries,
  onSelectDelivery,
  selectedDeliveryId,
}: DeliveryListProps) {
  const active = deliveries.filter((d) => d.status !== "delivered" && d.status !== "failed");
  const completed = deliveries.filter((d) => d.status === "delivered" || d.status === "failed");

  return (
    <div className="h-full flex flex-col">
      <div className="px-6 py-4 border-b border-white/10">
        <h2 className="text-xs font-semibold tracking-wide uppercase text-white/60">
          DELIVERY OPERATIONS
        </h2>
      </div>

      <div className="flex-1 overflow-y-auto">
        {/* Active Deliveries */}
        {active.length > 0 && (
          <div className="p-4">
            <div className="text-[10px] font-semibold tracking-wider uppercase text-white/40 mb-3 px-2">
              ACTIVE ({active.length})
            </div>
            <div className="space-y-2">
              {active.map((delivery) => (
                <DeliveryRow
                  key={delivery.id}
                  delivery={delivery}
                  onClick={() => onSelectDelivery(delivery)}
                  isSelected={delivery.id === selectedDeliveryId}
                />
              ))}
            </div>
          </div>
        )}

        {/* Completed Deliveries */}
        {completed.length > 0 && (
          <div className="p-4">
            <div className="text-[10px] font-semibold tracking-wider uppercase text-white/40 mb-3 px-2">
              COMPLETED ({completed.length})
            </div>
            <div className="space-y-2">
              {completed.map((delivery) => (
                <DeliveryRow
                  key={delivery.id}
                  delivery={delivery}
                  onClick={() => onSelectDelivery(delivery)}
                  isSelected={delivery.id === selectedDeliveryId}
                />
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function DeliveryRow({
  delivery,
  onClick,
  isSelected,
}: {
  delivery: Delivery;
  onClick: () => void;
  isSelected: boolean;
}) {
  const config = statusConfig[delivery.status];

  return (
    <motion.button
      onClick={onClick}
      whileHover={{ scale: 1.01 }}
      whileTap={{ scale: 0.99 }}
      className={`w-full text-left p-4 rounded-xl border transition-all ${
        isSelected
          ? "bg-aerly-accent/5 border-aerly-accent/30 shadow-glow"
          : "bg-white/[0.02] border-white/10 hover:border-white/20"
      }`}
    >
      <div className="flex items-start justify-between mb-2">
        <div>
          <div className="text-xs font-mono font-semibold text-white">{delivery.id}</div>
          <div className="text-[10px] text-white/50 mt-0.5">
            {delivery.droneId ? `Drone ${delivery.droneId}` : "Unassigned"}
          </div>
        </div>
        <div className={`px-2 py-1 rounded text-[9px] font-bold tracking-wider ${config.bg} ${config.color}`}>
          {config.label}
        </div>
      </div>

      <div className="flex items-center justify-between">
        <div className="text-[11px] text-white/70 truncate max-w-[60%]">
          {delivery.payload.description}
        </div>
        {delivery.eta && (
          <div className="text-xs font-mono font-semibold text-aerly-accent">{delivery.eta}</div>
        )}
      </div>
    </motion.button>
  );
}
