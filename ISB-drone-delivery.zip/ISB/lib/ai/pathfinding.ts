import { Coordinates, NoFlyZone } from "../types";

/**
 * A* pathfinding for drone navigation with no-fly zone avoidance
 */

interface PathNode {
  position: Coordinates;
  g: number; // Cost from start
  h: number; // Heuristic to goal
  f: number; // Total cost
  parent: PathNode | null;
}

/**
 * Calculate distance between two coordinates (Haversine formula)
 */
export function calculateDistance(a: Coordinates, b: Coordinates): number {
  const R = 6371; // Earth radius in km
  const dLat = ((b.lat - a.lat) * Math.PI) / 180;
  const dLng = ((b.lng - a.lng) * Math.PI) / 180;

  const aRad = (a.lat * Math.PI) / 180;
  const bRad = (b.lat * Math.PI) / 180;

  const x =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(aRad) * Math.cos(bRad) * Math.sin(dLng / 2) * Math.sin(dLng / 2);

  const c = 2 * Math.atan2(Math.sqrt(x), Math.sqrt(1 - x));
  return R * c;
}

/**
 * Check if a point intersects with any no-fly zone
 */
function isInNoFlyZone(point: Coordinates, noFlyZones: NoFlyZone[]): boolean {
  return noFlyZones.some((zone) => {
    if (!zone.active) return false;
    const distance = calculateDistance(point, zone.coordinates);
    return distance * 1000 < zone.radius; // Convert km to meters
  });
}

/**
 * Generate waypoints avoiding no-fly zones using simplified A*
 */
export function generateOptimalPath(
  start: Coordinates,
  goal: Coordinates,
  noFlyZones: NoFlyZone[]
): Coordinates[] {
  // For short distances, attempt direct path first
  const directDistance = calculateDistance(start, goal);

  // Check if direct path is safe
  const directPath = interpolatePath(start, goal, 20);
  const directPathSafe = !directPath.some((point) => isInNoFlyZone(point, noFlyZones));

  if (directPathSafe) {
    return [start, goal];
  }

  // Need to route around obstacles - use simplified pathfinding
  const path = findPathAroundObstacles(start, goal, noFlyZones);
  return path;
}

/**
 * Interpolate points along a line for collision detection
 */
function interpolatePath(start: Coordinates, end: Coordinates, segments: number): Coordinates[] {
  const points: Coordinates[] = [];
  for (let i = 0; i <= segments; i++) {
    const t = i / segments;
    points.push({
      lat: start.lat + (end.lat - start.lat) * t,
      lng: start.lng + (end.lng - start.lng) * t,
    });
  }
  return points;
}

/**
 * Find path around obstacles using waypoint generation
 */
function findPathAroundObstacles(
  start: Coordinates,
  goal: Coordinates,
  noFlyZones: NoFlyZone[]
): Coordinates[] {
  // Generate waypoints by finding clear corridors
  const waypoints: Coordinates[] = [start];

  // For each active no-fly zone between start and goal, create detour waypoints
  const affectedZones = noFlyZones.filter((zone) => {
    if (!zone.active) return false;
    const distToStart = calculateDistance(start, zone.coordinates);
    const distToGoal = calculateDistance(goal, zone.coordinates);
    const startGoalDist = calculateDistance(start, goal);
    // Zone is "between" start and goal if it's within the corridor
    return distToStart < startGoalDist && distToGoal < startGoalDist;
  });

  if (affectedZones.length === 0) {
    return [start, goal];
  }

  // Create waypoint that goes around the obstacle
  for (const zone of affectedZones) {
    // Calculate perpendicular offset from zone center
    const bearing = calculateBearing(start, goal);
    const detourPoint = offsetCoordinates(zone.coordinates, bearing + 90, zone.radius / 1000 + 0.5);

    // Verify detour point is safe
    if (!isInNoFlyZone(detourPoint, noFlyZones)) {
      waypoints.push(detourPoint);
    }
  }

  waypoints.push(goal);
  return waypoints;
}

/**
 * Calculate bearing between two points
 */
function calculateBearing(from: Coordinates, to: Coordinates): number {
  const dLng = ((to.lng - from.lng) * Math.PI) / 180;
  const fromLat = (from.lat * Math.PI) / 180;
  const toLat = (to.lat * Math.PI) / 180;

  const y = Math.sin(dLng) * Math.cos(toLat);
  const x =
    Math.cos(fromLat) * Math.sin(toLat) -
    Math.sin(fromLat) * Math.cos(toLat) * Math.cos(dLng);

  const bearing = Math.atan2(y, x);
  return ((bearing * 180) / Math.PI + 360) % 360;
}

/**
 * Offset coordinates by distance and bearing
 */
function offsetCoordinates(point: Coordinates, bearing: number, distance: number): Coordinates {
  const R = 6371; // Earth radius in km
  const bearingRad = (bearing * Math.PI) / 180;
  const latRad = (point.lat * Math.PI) / 180;
  const lngRad = (point.lng * Math.PI) / 180;

  const newLatRad = Math.asin(
    Math.sin(latRad) * Math.cos(distance / R) +
      Math.cos(latRad) * Math.sin(distance / R) * Math.cos(bearingRad)
  );

  const newLngRad =
    lngRad +
    Math.atan2(
      Math.sin(bearingRad) * Math.sin(distance / R) * Math.cos(latRad),
      Math.cos(distance / R) - Math.sin(latRad) * Math.sin(newLatRad)
    );

  return {
    lat: (newLatRad * 180) / Math.PI,
    lng: (newLngRad * 180) / Math.PI,
  };
}

/**
 * Estimate flight time based on distance and average speed
 */
export function estimateFlightTime(distance: number, averageSpeed: number = 40): number {
  // distance in km, speed in km/h, return time in minutes
  return (distance / averageSpeed) * 60;
}

/**
 * Estimate battery consumption for a route
 */
export function estimateBatteryConsumption(
  distance: number,
  payloadWeight: number,
  windSpeed: number = 0
): number {
  // Base consumption: 4% per km
  let consumption = distance * 4;

  // Payload penalty: 0.5% per 100g
  consumption += (payloadWeight / 0.1) * 0.5;

  // Wind penalty: 0.3% per km/h above 15 km/h
  if (windSpeed > 15) {
    consumption += (windSpeed - 15) * 0.3 * distance;
  }

  return Math.min(100, consumption);
}
