"use client";

import { useState, useEffect } from "react";
import { motion } from "framer-motion";

interface Telemetry {
  position: { lat: number; lng: number };
  altitude: number;
  groundSpeed: number;
  heading: number;
  battery: number;
  voltage: number;
  current: number;
  satellites: number;
  gpsFixType: number;
  armed: boolean;
  mode: string;
  timestamp: number;
}

export default function HardwarePanel() {
  const [connected, setConnected] = useState(false);
  const [connecting, setConnecting] = useState(false);
  const [telemetry, setTelemetry] = useState<Telemetry | null>(null);
  const [connectionType, setConnectionType] = useState<"serial" | "udp">("udp");
  const [host, setHost] = useState("127.0.0.1");
  const [port, setPort] = useState("14550");

  // Poll telemetry when connected
  useEffect(() => {
    if (!connected) return;

    const interval = setInterval(async () => {
      try {
        const res = await fetch("/api/hardware/connect");
        const data = await res.json();
        if (data.telemetry) {
          setTelemetry(data.telemetry);
        }
      } catch (error) {
        console.error("Failed to fetch telemetry:", error);
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [connected]);

  const handleConnect = async () => {
    setConnecting(true);
    try {
      const res = await fetch("/api/hardware/connect", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          type: connectionType,
          host: connectionType === "udp" ? host : undefined,
          udpPort: connectionType === "udp" ? parseInt(port) : undefined,
          port: connectionType === "serial" ? port : undefined,
          baudRate: 57600,
        }),
      });

      const data = await res.json();
      if (data.success) {
        setConnected(true);
      }
    } catch (error) {
      console.error("Connection failed:", error);
    } finally {
      setConnecting(false);
    }
  };

  const handleDisconnect = async () => {
    try {
      await fetch("/api/hardware/connect", { method: "DELETE" });
      setConnected(false);
      setTelemetry(null);
    } catch (error) {
      console.error("Disconnect failed:", error);
    }
  };

  return (
    <div className="bg-white/[0.02] border border-white/10 rounded-xl p-4">
      <h3 className="text-xs font-semibold tracking-wider uppercase text-white/60 mb-4">
        HARDWARE DRONE BRIDGE
      </h3>

      {!connected ? (
        <div className="space-y-3">
          <div>
            <label className="text-[10px] text-white/40 uppercase tracking-wider mb-1 block">
              Connection Type
            </label>
            <div className="flex gap-2">
              <button
                onClick={() => setConnectionType("udp")}
                className={`flex-1 py-2 px-3 rounded-lg text-xs font-semibold transition-all ${
                  connectionType === "udp"
                    ? "bg-aerly-accent text-aerly-dark"
                    : "bg-white/5 text-white/60 hover:bg-white/10"
                }`}
              >
                UDP
              </button>
              <button
                onClick={() => setConnectionType("serial")}
                className={`flex-1 py-2 px-3 rounded-lg text-xs font-semibold transition-all ${
                  connectionType === "serial"
                    ? "bg-aerly-accent text-aerly-dark"
                    : "bg-white/5 text-white/60 hover:bg-white/10"
                }`}
              >
                SERIAL
              </button>
            </div>
          </div>

          {connectionType === "udp" ? (
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-[10px] text-white/40 uppercase tracking-wider mb-1 block">
                  Host
                </label>
                <input
                  type="text"
                  value={host}
                  onChange={(e) => setHost(e.target.value)}
                  className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-white"
                  placeholder="127.0.0.1"
                />
              </div>
              <div>
                <label className="text-[10px] text-white/40 uppercase tracking-wider mb-1 block">
                  Port
                </label>
                <input
                  type="text"
                  value={port}
                  onChange={(e) => setPort(e.target.value)}
                  className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-white"
                  placeholder="14550"
                />
              </div>
            </div>
          ) : (
            <div>
              <label className="text-[10px] text-white/40 uppercase tracking-wider mb-1 block">
                Serial Port
              </label>
              <input
                type="text"
                value={port}
                onChange={(e) => setPort(e.target.value)}
                className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-white"
                placeholder="/dev/ttyUSB0"
              />
            </div>
          )}

          <button
            onClick={handleConnect}
            disabled={connecting}
            className={`w-full py-2.5 rounded-lg font-semibold text-sm tracking-wider uppercase transition-all ${
              connecting
                ? "bg-gray-600 text-white/40 cursor-not-allowed"
                : "bg-aerly-accent text-aerly-dark hover:shadow-glow"
            }`}
          >
            {connecting ? "CONNECTING..." : "CONNECT TO DRONE"}
          </button>

          <div className="mt-3 p-3 bg-aerly-accent/5 border border-aerly-accent/20 rounded-lg">
            <div className="text-[10px] text-aerly-accent font-semibold mb-1">INFO</div>
            <div className="text-[10px] text-white/60 leading-relaxed">
              Connect to PX4/ArduPilot autopilot via MAVLink. Use UDP for SITL simulation or WiFi
              telemetry. Use Serial for direct USB connection.
            </div>
          </div>
        </div>
      ) : (
        <div className="space-y-4">
          {/* Connection Status */}
          <div className="flex items-center justify-between p-3 bg-aerly-success/10 border border-aerly-success/30 rounded-lg">
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-aerly-success rounded-full animate-pulse" />
              <span className="text-sm font-semibold text-aerly-success">
                CONNECTED ({connectionType.toUpperCase()})
              </span>
            </div>
            <button
              onClick={handleDisconnect}
              className="text-xs text-white/60 hover:text-white transition-colors"
            >
              DISCONNECT
            </button>
          </div>

          {/* Telemetry */}
          {telemetry && (
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <TelemetryCard label="GPS FIX" value={telemetry.gpsFixType === 3 ? "3D FIX" : "NO FIX"} />
                <TelemetryCard label="SATELLITES" value={telemetry.satellites.toString()} />
                <TelemetryCard label="ALTITUDE" value={`${telemetry.altitude.toFixed(1)}m`} />
                <TelemetryCard label="SPEED" value={`${telemetry.groundSpeed.toFixed(1)} m/s`} />
                <TelemetryCard label="BATTERY" value={`${telemetry.battery.toFixed(0)}%`} />
                <TelemetryCard label="MODE" value={telemetry.mode} />
              </div>

              <div className="p-3 bg-white/[0.02] border border-white/10 rounded-lg">
                <div className="text-[10px] text-white/40 uppercase tracking-wider mb-1">Position</div>
                <div className="text-xs font-mono text-white">
                  {telemetry.position.lat.toFixed(6)}, {telemetry.position.lng.toFixed(6)}
                </div>
              </div>

              <div className="text-[9px] text-white/30 text-center">
                Updated {new Date(telemetry.timestamp).toLocaleTimeString()}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function TelemetryCard({ label, value }: { label: string; value: string }) {
  return (
    <div className="p-2 bg-white/[0.02] border border-white/10 rounded-lg">
      <div className="text-[9px] text-white/40 uppercase tracking-wider mb-0.5">{label}</div>
      <div className="text-sm font-mono font-semibold text-white">{value}</div>
    </div>
  );
}
