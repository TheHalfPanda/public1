"use client";

import { Drone, Coordinates } from "@/lib/types";
import { motion } from "framer-motion";
import { useState, useRef } from "react";

interface DroneMapProps {
  drones: Drone[];
}

const statusColors = {
  idle: "bg-gray-400",
  en_route: "bg-aerly-accent",
  returning: "bg-aerly-warning",
  charging: "bg-yellow-500",
  maintenance: "bg-red-500",
};

export default function DroneMap({ drones }: DroneMapProps) {
  // Simple 2D map visualization - centered on Hyderabad
  const baseLatitude = 17.385;
  const baseLongitude = 78.4867;

  // Pan and zoom state
  const [zoom, setZoom] = useState(1);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });
  const mapRef = useRef<HTMLDivElement>(null);

  const convertToMapPosition = (lat: number, lng: number) => {
    // Convert lat/lng to % position on a 600x400 map
    const x = ((lng - baseLongitude) * 10000 + 50) % 100;
    const y = ((baseLatitude - lat) * 10000 + 50) % 100;
    return { x: Math.max(5, Math.min(95, x)), y: Math.max(5, Math.min(95, y)) };
  };

  const handleWheel = (e: React.WheelEvent) => {
    e.preventDefault();
    const delta = e.deltaY * -0.001;
    const newZoom = Math.max(0.5, Math.min(3, zoom + delta));
    setZoom(newZoom);
  };

  const handleMouseDown = (e: React.MouseEvent) => {
    setIsDragging(true);
    setDragStart({ x: e.clientX - pan.x, y: e.clientY - pan.y });
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging) return;
    setPan({
      x: e.clientX - dragStart.x,
      y: e.clientY - dragStart.y,
    });
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  const resetView = () => {
    setZoom(1);
    setPan({ x: 0, y: 0 });
  };

  return (
    <div
      ref={mapRef}
      className="relative w-full h-full bg-gradient-to-br from-aerly-darker to-aerly-dark rounded-xl border border-white/10 overflow-hidden select-none"
      onWheel={handleWheel}
      onMouseDown={handleMouseDown}
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      onMouseLeave={handleMouseUp}
      style={{ cursor: isDragging ? 'grabbing' : 'grab' }}
    >
      {/* Zoom controls */}
      <div className="absolute top-4 right-4 z-20 flex flex-col gap-2">
        <button
          onClick={() => setZoom(Math.min(3, zoom + 0.2))}
          className="w-8 h-8 bg-aerly-darker/90 backdrop-blur-sm border border-white/20 rounded-lg text-white hover:bg-white/10 transition-colors flex items-center justify-center font-bold"
        >
          +
        </button>
        <button
          onClick={() => setZoom(Math.max(0.5, zoom - 0.2))}
          className="w-8 h-8 bg-aerly-darker/90 backdrop-blur-sm border border-white/20 rounded-lg text-white hover:bg-white/10 transition-colors flex items-center justify-center font-bold"
        >
          −
        </button>
        <button
          onClick={resetView}
          className="w-8 h-8 bg-aerly-darker/90 backdrop-blur-sm border border-white/20 rounded-lg text-white hover:bg-white/10 transition-colors flex items-center justify-center text-xs"
          title="Reset view"
        >
          ⟲
        </button>
      </div>

      {/* Transformable content wrapper */}
      <div
        className="absolute inset-0 transition-transform duration-100"
        style={{
          transform: `translate(${pan.x}px, ${pan.y}px) scale(${zoom})`,
          transformOrigin: 'center center',
        }}
      >
        {/* Grid overlay */}
        <div
          className="absolute inset-0 opacity-10"
          style={{
            backgroundImage: `
              linear-gradient(to right, rgba(0, 212, 255, 0.1) 1px, transparent 1px),
              linear-gradient(to bottom, rgba(0, 212, 255, 0.1) 1px, transparent 1px)
            `,
            backgroundSize: "40px 40px",
            width: '100%',
            height: '100%',
          }}
        />

      {/* Base station marker */}
      <div
        className="absolute w-4 h-4 -translate-x-1/2 -translate-y-1/2"
        style={{ left: "50%", top: "50%" }}
      >
        <div className="w-full h-full bg-aerly-success rounded-full animate-ping opacity-30" />
        <div className="absolute inset-0 w-full h-full bg-aerly-success rounded-full" />
      </div>

      {/* A* Planned Paths */}
      {drones.map((drone) => {
        if (!drone.plannedPath || drone.plannedPath.length < 2) return null;

        return (
          <svg
            key={`path-${drone.id}`}
            className="absolute inset-0 w-full h-full pointer-events-none"
            style={{ zIndex: 1 }}
          >
            <motion.path
              d={drone.plannedPath
                .map((point, idx) => {
                  const pos = convertToMapPosition(point.lat, point.lng);
                  return `${idx === 0 ? "M" : "L"} ${pos.x} ${pos.y}`;
                })
                .join(" ")}
              stroke="rgba(0, 212, 255, 0.3)"
              strokeWidth="1.5"
              fill="none"
              strokeDasharray="4 2"
              initial={{ pathLength: 0 }}
              animate={{ pathLength: 1 }}
              transition={{ duration: 0.8 }}
            />
            {/* Waypoint markers */}
            {drone.plannedPath.map((point, idx) => {
              const pos = convertToMapPosition(point.lat, point.lng);
              return (
                <circle
                  key={`waypoint-${drone.id}-${idx}`}
                  cx={pos.x}
                  cy={pos.y}
                  r="1"
                  fill="rgba(0, 212, 255, 0.5)"
                />
              );
            })}
          </svg>
        );
      })}

      {/* Drones */}
      {drones.map((drone) => {
        const pos = convertToMapPosition(drone.position.lat, drone.position.lng);
        return (
          <motion.div
            key={drone.id}
            className="absolute group"
            style={{ left: `${pos.x}%`, top: `${pos.y}%`, zIndex: 10 }}
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ type: "spring", damping: 15 }}
          >
            <motion.div
              className={`w-3 h-3 rounded-full ${statusColors[drone.status]} shadow-glow -translate-x-1/2 -translate-y-1/2`}
              animate={
                drone.status === "en_route"
                  ? { scale: [1, 1.2, 1] }
                  : {}
              }
              transition={{ repeat: Infinity, duration: 2 }}
            />

            {/* Tooltip on hover */}
            <div className="absolute left-4 top-0 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none z-10">
              <div className="bg-aerly-darker border border-white/20 rounded-lg p-2 text-xs whitespace-nowrap shadow-xl">
                <div className="font-mono font-bold text-white">{drone.callsign}</div>
                <div className="text-white/60 text-[10px] mt-0.5">
                  {drone.battery}% • {drone.status.replace("_", " ").toUpperCase()}
                </div>
                {drone.plannedPath && (
                  <div className="text-aerly-accent text-[10px] mt-0.5">
                    A* Path: {drone.plannedPath.length} waypoints
                  </div>
                )}
              </div>
            </div>
          </motion.div>
        );
      })}
      </div>

      {/* Legend - outside transform wrapper so it stays fixed */}
      <div className="absolute bottom-4 left-4 bg-aerly-darker/80 backdrop-blur-sm border border-white/10 rounded-lg p-3 z-20">
        <div className="text-[10px] font-semibold tracking-wider uppercase text-white/40 mb-2">
          STATUS
        </div>
        <div className="space-y-1.5">
          <LegendItem color="bg-aerly-accent" label="En Route" />
          <LegendItem color="bg-aerly-warning" label="Returning" />
          <LegendItem color="bg-gray-400" label="Idle" />
          <LegendItem color="bg-aerly-success" label="Base" />
        </div>
      </div>
    </div>
  );
}

function LegendItem({ color, label }: { color: string; label: string }) {
  return (
    <div className="flex items-center gap-2">
      <div className={`w-2 h-2 rounded-full ${color}`} />
      <div className="text-[10px] text-white/60">{label}</div>
    </div>
  );
}
