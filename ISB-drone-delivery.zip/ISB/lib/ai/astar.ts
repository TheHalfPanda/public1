import { Coordinates, NoFlyZone } from "../types";
import { calculateDistance } from "./pathfinding";

/**
 * Proper A* Pathfinding Implementation
 * Grid-based search with priority queue and heuristic optimization
 */

interface AStarNode {
  position: Coordinates;
  g: number; // Cost from start
  h: number; // Heuristic to goal
  f: number; // Total cost (g + h)
  parent: AStarNode | null;
  gridX: number;
  gridY: number;
}

class PriorityQueue<T> {
  private items: { element: T; priority: number }[] = [];

  enqueue(element: T, priority: number): void {
    const item = { element, priority };
    let added = false;

    for (let i = 0; i < this.items.length; i++) {
      if (item.priority < this.items[i].priority) {
        this.items.splice(i, 0, item);
        added = true;
        break;
      }
    }

    if (!added) {
      this.items.push(item);
    }
  }

  dequeue(): T | undefined {
    return this.items.shift()?.element;
  }

  isEmpty(): boolean {
    return this.items.length === 0;
  }

  size(): number {
    return this.items.length;
  }
}

/**
 * Grid-based spatial system for Hyderabad airspace
 * Resolution: 100m per grid cell
 */
const GRID_RESOLUTION = 0.0009; // ~100m in lat/lng degrees at Hyderabad latitude
const HYDERABAD_BOUNDS = {
  minLat: 17.25,
  maxLat: 17.55,
  minLng: 78.35,
  maxLng: 78.65,
};

export interface AStarResult {
  path: Coordinates[];
  cost: number;
  nodesExplored: number;
  openSet: Coordinates[]; // For visualization
  closedSet: Coordinates[]; // For visualization
}

/**
 * Convert coordinates to grid indices
 */
function coordsToGrid(coords: Coordinates): { x: number; y: number } {
  const x = Math.floor((coords.lng - HYDERABAD_BOUNDS.minLng) / GRID_RESOLUTION);
  const y = Math.floor((coords.lat - HYDERABAD_BOUNDS.minLat) / GRID_RESOLUTION);
  return { x, y };
}

/**
 * Convert grid indices to coordinates
 */
function gridToCoords(x: number, y: number): Coordinates {
  return {
    lat: HYDERABAD_BOUNDS.minLat + y * GRID_RESOLUTION,
    lng: HYDERABAD_BOUNDS.minLng + x * GRID_RESOLUTION,
  };
}

/**
 * Heuristic function: Euclidean distance (straight-line distance)
 */
function heuristic(a: Coordinates, b: Coordinates): number {
  return calculateDistance(a, b);
}

/**
 * Check if a grid cell is blocked by obstacles
 */
function isBlocked(coords: Coordinates, noFlyZones: NoFlyZone[]): boolean {
  for (const zone of noFlyZones) {
    if (!zone.active) continue;

    const distance = calculateDistance(coords, zone.coordinates);
    const distanceMeters = distance * 1000;

    if (distanceMeters < zone.radius) {
      return true;
    }
  }
  return false;
}

/**
 * Check if coordinates are within valid bounds
 */
function isInBounds(coords: Coordinates): boolean {
  return (
    coords.lat >= HYDERABAD_BOUNDS.minLat &&
    coords.lat <= HYDERABAD_BOUNDS.maxLat &&
    coords.lng >= HYDERABAD_BOUNDS.minLng &&
    coords.lng <= HYDERABAD_BOUNDS.maxLng
  );
}

/**
 * Generate valid neighbors (8-directional movement)
 */
function getNeighbors(node: AStarNode, noFlyZones: NoFlyZone[]): AStarNode[] {
  const neighbors: AStarNode[] = [];

  // 8 directions: N, S, E, W, NE, NW, SE, SW
  const directions = [
    { dx: 0, dy: 1 }, // North
    { dx: 0, dy: -1 }, // South
    { dx: 1, dy: 0 }, // East
    { dx: -1, dy: 0 }, // West
    { dx: 1, dy: 1 }, // NE
    { dx: -1, dy: 1 }, // NW
    { dx: 1, dy: -1 }, // SE
    { dx: -1, dy: -1 }, // SW
  ];

  for (const dir of directions) {
    const newX = node.gridX + dir.dx;
    const newY = node.gridY + dir.dy;
    const newCoords = gridToCoords(newX, newY);

    // Validate neighbor
    if (!isInBounds(newCoords) || isBlocked(newCoords, noFlyZones)) {
      continue;
    }

    // Calculate cost (diagonal moves cost more)
    const isDiagonal = dir.dx !== 0 && dir.dy !== 0;
    const moveCost = isDiagonal ? 1.414 : 1.0; // sqrt(2) for diagonal

    neighbors.push({
      position: newCoords,
      g: 0, // Will be set by A*
      h: 0, // Will be set by A*
      f: 0, // Will be set by A*
      parent: node,
      gridX: newX,
      gridY: newY,
    });
  }

  return neighbors;
}

/**
 * Reconstruct path from goal to start
 */
function reconstructPath(node: AStarNode): Coordinates[] {
  const path: Coordinates[] = [];
  let current: AStarNode | null = node;

  while (current !== null) {
    path.unshift(current.position);
    current = current.parent;
  }

  return path;
}

/**
 * Create unique key for grid position
 */
function nodeKey(x: number, y: number): string {
  return `${x},${y}`;
}

/**
 * A* Pathfinding Algorithm
 */
export function findPathAStar(
  start: Coordinates,
  goal: Coordinates,
  noFlyZones: NoFlyZone[]
): AStarResult {
  const startGrid = coordsToGrid(start);
  const goalGrid = coordsToGrid(goal);

  const startNode: AStarNode = {
    position: start,
    g: 0,
    h: heuristic(start, goal),
    f: heuristic(start, goal),
    parent: null,
    gridX: startGrid.x,
    gridY: startGrid.y,
  };

  const openSet = new PriorityQueue<AStarNode>();
  const closedSet = new Set<string>();
  const openSetMap = new Map<string, AStarNode>();

  openSet.enqueue(startNode, startNode.f);
  openSetMap.set(nodeKey(startGrid.x, startGrid.y), startNode);

  let nodesExplored = 0;
  const visualOpenSet: Coordinates[] = [];
  const visualClosedSet: Coordinates[] = [];

  // A* main loop
  while (!openSet.isEmpty()) {
    const current = openSet.dequeue();
    if (!current) break;

    const currentKey = nodeKey(current.gridX, current.gridY);
    openSetMap.delete(currentKey);
    nodesExplored++;

    // Goal reached
    if (current.gridX === goalGrid.x && current.gridY === goalGrid.y) {
      return {
        path: reconstructPath(current),
        cost: current.g,
        nodesExplored,
        openSet: Array.from(openSetMap.values()).map((n) => n.position),
        closedSet: visualClosedSet,
      };
    }

    closedSet.add(currentKey);
    visualClosedSet.push(current.position);

    // Explore neighbors
    const neighbors = getNeighbors(current, noFlyZones);

    for (const neighbor of neighbors) {
      const neighborKey = nodeKey(neighbor.gridX, neighbor.gridY);

      // Skip if already evaluated
      if (closedSet.has(neighborKey)) {
        continue;
      }

      // Calculate tentative g score
      const moveCost = calculateDistance(current.position, neighbor.position);
      const tentativeG = current.g + moveCost;

      // Check if this path is better
      const existingNode = openSetMap.get(neighborKey);

      if (!existingNode || tentativeG < existingNode.g) {
        neighbor.g = tentativeG;
        neighbor.h = heuristic(neighbor.position, goal);
        neighbor.f = neighbor.g + neighbor.h;
        neighbor.parent = current;

        if (!existingNode) {
          openSet.enqueue(neighbor, neighbor.f);
          openSetMap.set(neighborKey, neighbor);
          visualOpenSet.push(neighbor.position);
        } else {
          // Update existing node
          existingNode.g = tentativeG;
          existingNode.f = tentativeG + existingNode.h;
          existingNode.parent = current;
        }
      }
    }

    // Safety limit to prevent infinite loops
    if (nodesExplored > 10000) {
      console.warn("A* search limit reached, returning partial path");
      break;
    }
  }

  // No path found - return direct line as fallback
  console.warn("A* found no valid path, using direct fallback");
  return {
    path: [start, goal],
    cost: calculateDistance(start, goal),
    nodesExplored,
    openSet: visualOpenSet,
    closedSet: visualClosedSet,
  };
}

/**
 * Smooth path using Catmull-Rom spline interpolation
 * Reduces jagged grid-based paths to smooth curves
 */
export function smoothPath(path: Coordinates[], segments: number = 3): Coordinates[] {
  if (path.length < 3) return path;

  const smoothed: Coordinates[] = [path[0]];

  for (let i = 0; i < path.length - 1; i++) {
    const p0 = path[Math.max(0, i - 1)];
    const p1 = path[i];
    const p2 = path[i + 1];
    const p3 = path[Math.min(path.length - 1, i + 2)];

    for (let t = 0; t < segments; t++) {
      const t_norm = t / segments;
      const tt = t_norm * t_norm;
      const ttt = tt * t_norm;

      // Catmull-Rom basis
      const lat =
        0.5 *
        (2 * p1.lat +
          (-p0.lat + p2.lat) * t_norm +
          (2 * p0.lat - 5 * p1.lat + 4 * p2.lat - p3.lat) * tt +
          (-p0.lat + 3 * p1.lat - 3 * p2.lat + p3.lat) * ttt);

      const lng =
        0.5 *
        (2 * p1.lng +
          (-p0.lng + p2.lng) * t_norm +
          (2 * p0.lng - 5 * p1.lng + 4 * p2.lng - p3.lng) * tt +
          (-p0.lng + 3 * p1.lng - 3 * p2.lng + p3.lng) * ttt);

      smoothed.push({ lat, lng });
    }
  }

  smoothed.push(path[path.length - 1]);
  return smoothed;
}

/**
 * Simplify path using Ramer-Douglas-Peucker algorithm
 * Reduces waypoint count while preserving path shape
 */
export function simplifyPath(path: Coordinates[], epsilon: number = 0.0001): Coordinates[] {
  if (path.length < 3) return path;

  // Find point with maximum distance from line
  let maxDist = 0;
  let index = 0;

  const start = path[0];
  const end = path[path.length - 1];

  for (let i = 1; i < path.length - 1; i++) {
    const dist = perpendicularDistance(path[i], start, end);
    if (dist > maxDist) {
      maxDist = dist;
      index = i;
    }
  }

  // If max distance is greater than epsilon, recursively simplify
  if (maxDist > epsilon) {
    const left = simplifyPath(path.slice(0, index + 1), epsilon);
    const right = simplifyPath(path.slice(index), epsilon);

    return [...left.slice(0, -1), ...right];
  } else {
    return [start, end];
  }
}

/**
 * Calculate perpendicular distance from point to line
 */
function perpendicularDistance(
  point: Coordinates,
  lineStart: Coordinates,
  lineEnd: Coordinates
): number {
  const dx = lineEnd.lng - lineStart.lng;
  const dy = lineEnd.lat - lineStart.lat;

  const numerator = Math.abs(
    dy * point.lng - dx * point.lat + lineEnd.lat * lineStart.lng - lineEnd.lng * lineStart.lat
  );

  const denominator = Math.sqrt(dy * dy + dx * dx);

  return numerator / denominator;
}
