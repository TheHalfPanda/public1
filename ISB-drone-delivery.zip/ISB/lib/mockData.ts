import { Drone, Delivery, NoFlyZone, Alert, WeatherCondition } from "./types";

// Hyderabad Hi-Tech City coordinates - Virtual Demo Environment
// Note: No physical drones deployed yet - this is simulation for investor demonstrations
const HITEC_CITY_BASE = { lat: 17.4435, lng: 78.3772 }; // Near Cyber Towers

// VIRTUAL DRONE FLEET - Simulated for demonstration purposes
export const drones: Drone[] = [
  {
    id: "AE-DEMO-01",
    callsign: "SIERRA-01",
    status: "en_route",
    battery: 87,
    position: { lat: 17.4489, lng: 78.3808 }, // Near Gachibowli
    assignedDelivery: "DEL-HYD-001",
    eta: "4m 30s",
    payload: "Emergency medication",
    temperature: 42,
    altitude: 80,
    speed: 38,
  },
  {
    id: "AE-DEMO-02",
    callsign: "TANGO-02",
    status: "returning",
    battery: 34,
    position: { lat: 17.4512, lng: 78.3845 }, // Near Mindspace
    temperature: 45,
    altitude: 75,
    speed: 35,
  },
  {
    id: "AE-DEMO-03",
    callsign: "WHISKEY-03",
    status: "idle",
    battery: 100,
    position: HITEC_CITY_BASE,
    temperature: 38,
    altitude: 0,
    speed: 0,
  },
  {
    id: "AE-DEMO-04",
    callsign: "VICTOR-04",
    status: "charging",
    battery: 68,
    position: HITEC_CITY_BASE,
    temperature: 40,
    altitude: 0,
    speed: 0,
  },
];

// SIMULATED DELIVERY SCENARIOS - Based on realistic Hi-Tech City use cases
export const deliveries: Delivery[] = [
  {
    id: "DEL-HYD-001",
    droneId: "AE-DEMO-01",
    status: "in_flight",
    pickup: {
      name: "Apollo Pharmacy - Gachibowli",
      address: "Anjaiah Nagar, Gachibowli, Hyderabad 500032",
      coordinates: { lat: 17.4400, lng: 78.3486 },
    },
    dropoff: {
      name: "My Home Jewel - Apartment C-304",
      address: "Gopanpally, Serilingampally, Hyderabad 500046",
      coordinates: { lat: 17.4587, lng: 78.3512 },
    },
    payload: {
      weight: 0.35,
      description: "Emergency asthma inhaler + BP medication",
      category: "pharmacy",
    },
    distance: 2.8,
    eta: "4m 30s",
    timeOrdered: new Date(Date.now() - 5 * 60 * 1000).toISOString(),
    sla: 10,
    cost: {
      aerly: 15,
      bikeCourier: 45,
      savings: 30,
    },
    co2: {
      aerly: 0.008,
      bikeCourier: 0.067,
      savedKg: 0.059,
    },
  },
  {
    id: "DEL-HYD-002",
    droneId: null,
    status: "queued",
    pickup: {
      name: "MedPlus - Madhapur",
      address: "Ayyappa Society, Madhapur, Hyderabad 500081",
      coordinates: { lat: 17.4485, lng: 78.3908 },
    },
    dropoff: {
      name: "Raheja Mindspace - Tower 3, Floor 8",
      address: "Mindspace Junction, Hi-Tech City, Hyderabad 500081",
      coordinates: { lat: 17.4375, lng: 78.3809 },
    },
    payload: {
      weight: 0.28,
      description: "Diabetes test strips + insulin pen",
      category: "pharmacy",
    },
    distance: 1.6,
    eta: null,
    timeOrdered: new Date(Date.now() - 1 * 60 * 1000).toISOString(),
    sla: 10,
    cost: {
      aerly: 12,
      bikeCourier: 38,
      savings: 26,
    },
    co2: {
      aerly: 0.005,
      bikeCourier: 0.048,
      savedKg: 0.043,
    },
  },
  {
    id: "DEL-HYD-003",
    droneId: null,
    status: "queued",
    pickup: {
      name: "Care Hospital Pharmacy",
      address: "Road No 1, Banjara Hills, Hyderabad 500034",
      coordinates: { lat: 17.4183, lng: 78.4365 },
    },
    dropoff: {
      name: "Prestige Falcon City - Block B",
      address: "Kothaguda, Kondapur, Hyderabad 500084",
      coordinates: { lat: 17.4652, lng: 78.3621 },
    },
    payload: {
      weight: 0.52,
      description: "Post-operative medication kit (temperature controlled)",
      category: "medical",
    },
    distance: 6.4,
    eta: null,
    timeOrdered: new Date(Date.now() - 45 * 1000).toISOString(),
    sla: 10,
    cost: {
      aerly: 20,
      bikeCourier: 55,
      savings: 35,
    },
    co2: {
      aerly: 0.016,
      bikeCourier: 0.128,
      savedKg: 0.112,
    },
  },
  {
    id: "DEL-HYD-004",
    droneId: null,
    status: "queued",
    pickup: {
      name: "1mg Pharma - Kavuri Hills",
      address: "Madhapur Main Road, Hyderabad 500033",
      coordinates: { lat: 17.4372, lng: 78.3952 },
    },
    dropoff: {
      name: "DLF Cyber City - Building 5",
      address: "Gachibowli, Hyderabad 500032",
      coordinates: { lat: 17.4266, lng: 78.3489 },
    },
    payload: {
      weight: 0.18,
      description: "Urgent prescription refill - cardiac medication",
      category: "pharmacy",
    },
    distance: 3.2,
    eta: null,
    timeOrdered: new Date(Date.now() - 30 * 1000).toISOString(),
    sla: 10,
    cost: {
      aerly: 16,
      bikeCourier: 42,
      savings: 26,
    },
    co2: {
      aerly: 0.009,
      bikeCourier: 0.076,
      savedKg: 0.067,
    },
  },
  {
    id: "DEL-HYD-005",
    droneId: "AE-DEMO-02",
    status: "delivered",
    pickup: {
      name: "Apollo Pharmacy - Kukatpally",
      address: "KPHB Main Road, Hyderabad 500072",
      coordinates: { lat: 17.4944, lng: 78.3912 },
    },
    dropoff: {
      name: "Aparna Sarovar Zenith - Tower A",
      address: "Nallagandla, Hyderabad 500019",
      coordinates: { lat: 17.4721, lng: 78.3576 },
    },
    payload: {
      weight: 0.42,
      description: "Child fever medication + electrolytes",
      category: "pharmacy",
    },
    distance: 4.1,
    eta: null,
    timeOrdered: new Date(Date.now() - 18 * 60 * 1000).toISOString(),
    timeDelivered: new Date(Date.now() - 11 * 60 * 1000).toISOString(),
    sla: 10,
    cost: {
      aerly: 17,
      bikeCourier: 48,
      savings: 31,
    },
    co2: {
      aerly: 0.011,
      bikeCourier: 0.098,
      savedKg: 0.087,
    },
  },
];

// REALISTIC NO-FLY ZONES - Hyderabad airspace restrictions
export const noFlyZones: NoFlyZone[] = [
  {
    id: "NFZ-HYD-001",
    name: "Rajiv Gandhi International Airport",
    coordinates: { lat: 17.2403, lng: 78.4294 },
    radius: 5000,
    reason: "Commercial aviation operations - DGCA restricted airspace",
    active: true,
  },
  {
    id: "NFZ-HYD-002",
    name: "Begumpet Airport",
    coordinates: { lat: 17.4531, lng: 78.4676 },
    radius: 2500,
    reason: "Civil aviation & Air Force operations",
    active: true,
  },
  {
    id: "NFZ-HYD-003",
    name: "Raj Bhavan (Governor's Residence)",
    coordinates: { lat: 17.4132, lng: 78.4686 },
    radius: 800,
    reason: "Government security zone",
    active: true,
  },
  {
    id: "NFZ-HYD-004",
    name: "Secretariat Complex",
    coordinates: { lat: 17.4326, lng: 78.4774 },
    radius: 1000,
    reason: "State government operations - security restriction",
    active: true,
  },
  {
    id: "NFZ-HYD-005",
    name: "Hussain Sagar Lake",
    coordinates: { lat: 17.4239, lng: 78.4738 },
    radius: 1200,
    reason: "Public safety - water body restrictions",
    active: true,
  },
];

// SIMULATED SYSTEM ALERTS - Demo scenarios
export const alerts: Alert[] = [
  {
    id: "ALT-001",
    severity: "warning",
    category: "battery",
    message: "TANGO-02 battery at 34% - returning to base for charging",
    droneId: "AE-DEMO-02",
    timestamp: new Date(Date.now() - 3 * 60 * 1000).toISOString(),
    resolved: false,
  },
  {
    id: "ALT-002",
    severity: "info",
    category: "system",
    message: "4 deliveries queued - demo simulation active",
    timestamp: new Date(Date.now() - 1 * 60 * 1000).toISOString(),
    resolved: false,
  },
];

// HYDERABAD WEATHER CONDITIONS - Realistic for demonstration
export const weather: WeatherCondition = {
  windSpeed: 12,
  windDirection: 180,
  temperature: 32,
  visibility: 10.0,
  conditions: "Clear",
};
