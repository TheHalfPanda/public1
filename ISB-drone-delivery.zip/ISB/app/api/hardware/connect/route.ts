import { NextResponse } from "next/server";
import { MAVLinkDrone } from "@/lib/hardware/mavlink";

/**
 * Hardware drone connection endpoint
 * POST /api/hardware/connect
 */

let droneInstance: MAVLinkDrone | null = null;

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { type, port, host, udpPort, baudRate } = body;

    // Create new drone connection
    droneInstance = new MAVLinkDrone({
      type,
      port,
      host,
      udpPort: udpPort || 14550,
      baudRate: baudRate || 57600,
    });

    const success = await droneInstance.connect();

    if (!success) {
      return NextResponse.json({ error: "Failed to connect to drone" }, { status: 500 });
    }

    return NextResponse.json({
      success: true,
      message: "Connected to hardware drone",
      connectionType: type,
    });
  } catch (error) {
    console.error("Hardware connection error:", error);
    return NextResponse.json({ error: "Connection failed" }, { status: 500 });
  }
}

export async function GET() {
  if (!droneInstance) {
    return NextResponse.json({ connected: false });
  }

  return NextResponse.json({
    connected: droneInstance.isConnected(),
    telemetry: droneInstance.getTelemetry(),
  });
}

export async function DELETE() {
  if (droneInstance) {
    await droneInstance.disconnect();
    droneInstance = null;
  }

  return NextResponse.json({ success: true, message: "Disconnected" });
}
