"use client";

import { useEffect, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { DroneVideoStream, VideoStreamConfig } from "@/lib/hardware/video";
import { Coordinates } from "@/lib/types";

interface VideoStreamProps {
  streamConfig?: VideoStreamConfig;
  dronePosition?: Coordinates;
  plannedPath?: Coordinates[];
  telemetry?: {
    altitude: number;
    speed: number;
    battery: number;
    heading: number;
  };
  showOverlay?: boolean;
}

export default function VideoStream({
  streamConfig,
  dronePosition,
  plannedPath,
  telemetry,
  showOverlay = true,
}: VideoStreamProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isStreaming, setIsStreaming] = useState(false);
  const [streamInstance, setStreamInstance] = useState<DroneVideoStream | null>(null);
  const [showConfig, setShowConfig] = useState(false);
  const [config, setConfig] = useState<VideoStreamConfig>({
    protocol: "mjpeg",
    url: "http://192.168.1.100:81/stream",
  });

  // Start stream when config provided
  useEffect(() => {
    if (streamConfig && videoRef.current && !streamInstance) {
      const stream = new DroneVideoStream(streamConfig);
      stream.start(videoRef.current).then((success) => {
        if (success) {
          setIsStreaming(true);
          setStreamInstance(stream);
        }
      });
    }

    return () => {
      if (streamInstance) {
        streamInstance.stop();
      }
    };
  }, [streamConfig]);

  // Draw algorithm overlay on canvas
  useEffect(() => {
    if (!canvasRef.current || !videoRef.current || !showOverlay) return;

    const canvas = canvasRef.current;
    const video = videoRef.current;

    canvas.width = video.videoWidth || 1280;
    canvas.height = video.videoHeight || 720;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const drawOverlay = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      // Telemetry overlay
      if (telemetry) {
        ctx.font = "bold 24px monospace";
        ctx.fillStyle = "rgba(0, 0, 0, 0.7)";
        ctx.fillRect(20, 20, 300, 160);

        ctx.fillStyle = "#00d4ff";
        ctx.fillText(`ALT: ${telemetry.altitude.toFixed(1)}m`, 35, 55);
        ctx.fillText(`SPD: ${telemetry.speed.toFixed(1)} m/s`, 35, 90);
        ctx.fillText(`BAT: ${telemetry.battery.toFixed(0)}%`, 35, 125);
        ctx.fillText(`HDG: ${telemetry.heading.toFixed(0)}°`, 35, 160);
      }

      // A* path visualization (simplified for video overlay)
      if (plannedPath && plannedPath.length > 1) {
        ctx.strokeStyle = "#00ff88";
        ctx.lineWidth = 3;
        ctx.setLineDash([10, 5]);

        ctx.beginPath();
        const startY = canvas.height - 100;
        const pathWidth = 400;

        plannedPath.forEach((_, idx) => {
          const x = 50 + (idx / plannedPath.length) * pathWidth;
          const y = startY + Math.sin(idx * 0.5) * 20;

          if (idx === 0) {
            ctx.moveTo(x, y);
          } else {
            ctx.lineTo(x, y);
          }
        });

        ctx.stroke();
        ctx.setLineDash([]);

        // Path label
        ctx.font = "14px monospace";
        ctx.fillStyle = "#00ff88";
        ctx.fillText(`A* PATH: ${plannedPath.length} waypoints`, 50, startY - 20);
      }

      // Current position indicator
      if (dronePosition) {
        ctx.fillStyle = "#ff3366";
        ctx.beginPath();
        ctx.arc(canvas.width / 2, canvas.height / 2, 15, 0, 2 * Math.PI);
        ctx.fill();

        ctx.strokeStyle = "#ff3366";
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.arc(canvas.width / 2, canvas.height / 2, 25, 0, 2 * Math.PI);
        ctx.stroke();
      }

      // AERLY watermark
      ctx.font = "bold 16px sans-serif";
      ctx.fillStyle = "rgba(0, 212, 255, 0.8)";
      ctx.fillText("AERLY AUTONOMOUS", canvas.width - 220, canvas.height - 20);

      requestAnimationFrame(drawOverlay);
    };

    drawOverlay();
  }, [showOverlay, telemetry, plannedPath, dronePosition]);

  const handleStartStream = async () => {
    if (!videoRef.current) return;

    const stream = new DroneVideoStream(config);
    const success = await stream.start(videoRef.current);

    if (success) {
      setIsStreaming(true);
      setStreamInstance(stream);
      setShowConfig(false);
    }
  };

  const handleStopStream = () => {
    if (streamInstance) {
      streamInstance.stop();
      setStreamInstance(null);
      setIsStreaming(false);
    }
  };

  return (
    <div className="relative w-full h-full bg-aerly-darker rounded-xl overflow-hidden border border-white/10">
      {/* Video element */}
      <video
        ref={videoRef}
        autoPlay
        playsInline
        muted
        className="w-full h-full object-cover"
      />

      {/* Algorithm overlay canvas */}
      <canvas
        ref={canvasRef}
        className="absolute inset-0 w-full h-full pointer-events-none"
        style={{ mixBlendMode: "screen" }}
      />

      {/* No stream placeholder */}
      {!isStreaming && !showConfig && (
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-aerly-darker">
          <svg
            className="w-24 h-24 text-white/20 mb-6"
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={1.5}
              d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z"
            />
          </svg>
          <div className="text-sm font-semibold text-white/60 mb-2">NO CAMERA FEED</div>
          <div className="text-xs text-white/40 mb-6">Connect drone camera to stream live video</div>
          <button
            onClick={() => setShowConfig(true)}
            className="px-6 py-2.5 bg-aerly-accent text-aerly-dark font-semibold text-sm tracking-wider uppercase rounded-lg hover:shadow-glow transition-all"
          >
            CONFIGURE STREAM
          </button>
        </div>
      )}

      {/* Stream configuration modal */}
      <AnimatePresence>
        {showConfig && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 bg-aerly-darker/95 backdrop-blur-sm flex items-center justify-center p-6"
          >
            <div className="w-full max-w-md space-y-4">
              <h3 className="text-lg font-bold text-white mb-4">CAMERA STREAM SETUP</h3>

              <div>
                <label className="text-[10px] text-white/40 uppercase tracking-wider mb-2 block">
                  Protocol
                </label>
                <div className="grid grid-cols-4 gap-2">
                  {(["webrtc", "mjpeg", "rtsp", "hls"] as const).map((protocol) => (
                    <button
                      key={protocol}
                      onClick={() => setConfig({ ...config, protocol })}
                      className={`py-2 px-3 rounded-lg text-xs font-semibold uppercase transition-all ${
                        config.protocol === protocol
                          ? "bg-aerly-accent text-aerly-dark"
                          : "bg-white/5 text-white/60 hover:bg-white/10"
                      }`}
                    >
                      {protocol}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="text-[10px] text-white/40 uppercase tracking-wider mb-2 block">
                  Stream URL
                </label>
                <input
                  type="text"
                  value={config.url}
                  onChange={(e) => setConfig({ ...config, url: e.target.value })}
                  placeholder="http://192.168.1.100:81/stream"
                  className="w-full bg-white/5 border border-white/10 rounded-lg px-4 py-3 text-sm text-white font-mono"
                />
              </div>

              <div className="p-4 bg-aerly-accent/5 border border-aerly-accent/20 rounded-lg">
                <div className="text-[10px] text-aerly-accent font-semibold mb-2">EXAMPLES</div>
                <div className="text-[10px] text-white/60 space-y-1 font-mono">
                  <div>MJPEG: http://drone-ip:81/stream</div>
                  <div>WebRTC: http://drone-ip:8080/offer</div>
                  <div>HLS: http://drone-ip/stream.m3u8</div>
                </div>
              </div>

              <div className="flex gap-3">
                <button
                  onClick={() => setShowConfig(false)}
                  className="flex-1 py-2.5 bg-white/5 text-white/60 font-semibold text-sm tracking-wider uppercase rounded-lg hover:bg-white/10 transition-all"
                >
                  CANCEL
                </button>
                <button
                  onClick={handleStartStream}
                  className="flex-1 py-2.5 bg-aerly-accent text-aerly-dark font-semibold text-sm tracking-wider uppercase rounded-lg hover:shadow-glow transition-all"
                >
                  START STREAM
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Stream controls */}
      {isStreaming && (
        <div className="absolute top-4 right-4 flex gap-2">
          <button
            onClick={() => setShowConfig(true)}
            className="p-2 bg-aerly-darker/80 backdrop-blur-sm border border-white/10 rounded-lg hover:bg-aerly-darker transition-all"
            title="Settings"
          >
            <svg className="w-4 h-4 text-white/80" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"
              />
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
            </svg>
          </button>
          <button
            onClick={handleStopStream}
            className="p-2 bg-aerly-danger/80 backdrop-blur-sm border border-aerly-danger/30 rounded-lg hover:bg-aerly-danger transition-all"
            title="Stop Stream"
          >
            <svg className="w-4 h-4 text-white" fill="currentColor" viewBox="0 0 24 24">
              <rect x="6" y="6" width="12" height="12" />
            </svg>
          </button>
        </div>
      )}

      {/* Live indicator */}
      {isStreaming && (
        <div className="absolute top-4 left-4 flex items-center gap-2 px-3 py-1.5 bg-aerly-danger/80 backdrop-blur-sm border border-aerly-danger/30 rounded-lg">
          <div className="w-2 h-2 bg-white rounded-full animate-pulse" />
          <span className="text-xs font-bold text-white tracking-wider">LIVE</span>
        </div>
      )}
    </div>
  );
}
