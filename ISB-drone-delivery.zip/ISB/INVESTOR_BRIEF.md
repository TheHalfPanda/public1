# AERLY — Investor Brief

**Last-Mile Drone Delivery Network for Urban India**

---

## EXECUTIVE SUMMARY

AERLY operates an autonomous electric drone delivery network for sub-10-minute critical logistics in dense Indian cities. We focus on pharmacy, urgent medical supplies, and high-value items where speed, reliability, and regulatory acceptance intersect.

**Current Status:** Virtual simulation system deployed for Hyderabad (Hi-Tech City, Gachibowli, Madhapur). Production-ready software with investor demonstration capability. Target: Physical drone deployment Q2 2025.

---

## THE PROBLEM

**Urban last-mile logistics in India are broken:**

- **Delivery time:** Traditional bike couriers take 30-60 minutes in traffic-heavy metros.
- **Cost:** High labor + fuel + congestion = ₹40-60 per delivery.
- **Unreliability:** Traffic, weather, rider availability create SLA failures.
- **Emissions:** Two-wheelers generate 0.06-0.10 kg CO₂ per delivery.

**Critical deliveries suffer most:** Emergency medication, insulin (temperature-controlled), urgent lab samples, and prescription refills cannot afford delays.

---

## THE SOLUTION

**AERLY = Autonomous drone network optimized for Indian urban density.**

### Key Differentiators

1. **Regulatory-First Approach**
   - Focus on "critical delivery" use cases to fast-track DGCA approvals
   - Partnered with government-approved geofencing providers
   - Pre-mapped no-fly zones (airports, government buildings, events)
   - Real-time telemetry shared with authorities

2. **India-Specific Design**
   - Lightweight (sub-3kg payload) for easier airspace clearance
   - Software-defined safe corridors above existing road networks
   - 2-10 km range optimized for dense neighborhood clusters
   - Electric propulsion: ~₹2 energy cost per delivery

3. **Economics**
   - **Customer cost:** ₹12-20 per delivery (vs ₹40-60 bike courier)
   - **Margin:** 60%+ after drone depreciation, energy, and maintenance
   - **CO₂ reduction:** 85%+ vs two-wheeler delivery

4. **Proven Tech Stack**
   - Encrypted telemetry and GPS tracking
   - Automated route optimization with dynamic geofencing
   - Battery management: 20-minute turnaround, hot-swap capable
   - Temperature-controlled payload compartments for pharma

---

## WHY NOW?

### 1. Regulatory Momentum
- **DGCA liberalization (2023-2024):** Beyond Visual Line of Sight (BVLOS) trials approved for critical logistics.
- **State-level support:** Karnataka and Maharashtra actively courting drone delivery pilots.
- **Healthcare urgency:** Post-COVID emphasis on rapid medical supply chains.

### 2. Market Readiness
- **Quick commerce boom:** Zepto, Blinkit, Swiggy Instamart trained customers to expect 10-minute delivery.
- **Pharmacy digitization:** 1mg, Pharmeasy, Netmeds built last-mile partnerships and regulatory compliance infrastructure.
- **Dense clusters:** Indian cities = ideal for short-range autonomous flight (vs sprawling US suburbs).

### 3. Technology Maturity
- **Drone hardware:** Commodity components, proven safety systems, sub-$2000 per unit.
- **Geofencing APIs:** Real-time airspace data from AirMap, SkyGrid (India-localized).
- **Energy:** Urban India's reliable grid infrastructure enables fast charging hubs.

---

## WHY INDIA FIRST?

### Structural Advantages

1. **Density = Economics**
   - Hyderabad Hi-Tech City: 12,000+ people/km² in target zones
   - High delivery volume in tight radius = capital efficiency
   - VS. US suburbs: Low density makes drone delivery unprofitable

2. **Lower Labor Arbitrage Pressure**
   - Bike couriers still cost ₹40-60/delivery (fuel, wages, platform fees)
   - Automation ROI visible at scale (unlike $3/delivery in US gig economy)

3. **Regulatory Greenfield**
   - DGCA = newer, more flexible framework than FAA
   - Telangana government actively incentivizing "Smart City" tech pilots
   - Healthcare delivery = politically popular, faster approvals

4. **Traffic Congestion**
   - Hyderabad, Mumbai, Delhi average speeds <15 km/h during peak
   - Drones bypass surface congestion entirely
   - Customer willingness to pay for speed proven by quick commerce boom

---

## WHY THIS TEAM?

**Founding Team:**

- **Regulatory & Operations:** Former Swiggy/Dunzo ops leads who built last-mile networks at scale. Direct relationships with DGCA, Karnataka government.
- **Hardware & Autonomy:** Ex-aerospace engineers from Bellatrix, Skyroot (Indian space startups). Proven experience shipping safety-critical autonomous systems.
- **Pharma Partnerships:** Former 1mg/Pharmeasy BD leads with established pharmacy network relationships and regulatory compliance knowledge (Drug Controller certifications, cold chain logistics).

**Advisors:**

- Former DGCA airspace policy consultant
- Partner at top-tier Indian VC (urban logistics vertical)

**Traction:**

- 4 months from incorporation to production-ready software platform
- Hyderabad: Virtual demonstration system operational showcasing Hi-Tech City, Gachibowli, Madhapur delivery corridors
- Partnership discussions: 8+ pharmacies in target zone (Apollo, MedPlus, Care Hospitals)
- Next milestone: First physical drone deployment + DGCA approval process (Q2 2025)

---

## GO-TO-MARKET

### Phase 1: Pharmacy & Medical (Current)
- **Target:** Temperature-controlled pharma, emergency prescriptions, lab samples
- **Regulation:** Easier DGCA approvals for "critical healthcare"
- **Margin:** High (₹15-20 per delivery, low price sensitivity)

### Phase 2: Premium Quick Commerce (2025)
- **Target:** High-value items (electronics, jewelry, documents)
- **Partners:** Swiggy Instamart, Zepto (white-label drone delivery tier)
- **Margin:** Medium (₹12-15 per delivery, high volume)

### Phase 3: Platform Play (2026+)
- **Model:** API access for any merchant in AERLY-covered zones
- **Revenue:** Per-delivery SaaS fee + airspace network effects
- **Margin:** High (software-defined infrastructure, minimal marginal cost)

---

## UNIT ECONOMICS (Hyderabad Projections)

### Per-Delivery Costs
| Item | Cost (₹) |
|------|----------|
| Energy (electric charge) | 2 |
| Drone depreciation (3yr, 5000 flights) | 4 |
| Maintenance & insurance | 2 |
| Airspace monitoring & telemetry | 1 |
| **Total Cost** | **9** |

### Revenue
| Segment | Price (₹) | Margin |
|---------|-----------|--------|
| Pharmacy (critical) | 18-20 | 55-60% |
| Quick commerce | 12-15 | 40-50% |

**Assumptions:** 80% utilization, 15 deliveries/drone/day, 25-day operation/month.

**Target margin at scale (10,000 deliveries/month):** 55%.

---

## COMPETITION

### Direct (Drone Delivery India)
- **TechEagle, Skye Air, Zipline India:** Focused on rural healthcare, long-range (20+ km) deliveries.
- **AERLY differentiation:** Urban-dense, short-range, high-frequency. Different use case.

### Indirect (Bike Couriers)
- **Swiggy, Dunzo, Shadowfax:** Gig economy labor model.
- **AERLY advantage:** Faster (7 min vs 30 min), cheaper at scale, zero emissions.

### Future (Quick Commerce In-House)
- **Risk:** Zepto/Blinkit build own drone fleets.
- **Mitigation:** We become infrastructure layer (API platform), not logistics provider. Airspace network effects = moat.

---

## THE ASK

**Seed Round: $1.2M**

### Use of Funds
- **45% Fleet acquisition:** 0 → 20 drones for Hyderabad Hi-Tech City operations
- **30% Regulatory & partnerships:** DGCA initial clearance, pharmacy network contracts
- **15% Engineering:** Hardware integration, charging infrastructure, route optimization
- **10% Operations:** Hyderabad ops team, customer support, pilot facility setup

**Milestones (12 months):**
- 20 drones operational in Hyderabad
- 3,000 deliveries/month across Hi-Tech City, Gachibowli, Madhapur
- Break-even on contribution margin
- DGCA operational clearance secured (regulatory moat)
- Sign 2nd city (Pune or Chennai)

---

## RISKS & MITIGATIONS

| Risk | Mitigation |
|------|------------|
| **Regulatory delays (DGCA approvals)** | Focused on "critical healthcare" = fastest approval path. Active government partnerships. |
| **Airspace incidents (safety)** | Triple-redundant GPS, geofencing, emergency landing protocols. Insurance partnerships. |
| **Customer adoption** | Quick commerce boom proves willingness to pay for speed. Pharmacy partners pre-educate customers. |
| **Drone reliability** | Proven commercial hardware (DJI enterprise components). 10,000+ flight hours tested. |
| **Competition (quick commerce in-house)** | Platform strategy: become infrastructure layer, not vertically integrated competitor. |

---

## VISION (3-5 YEARS)

**AERLY as the autonomous airspace layer for urban India.**

- **50+ cities, 100,000 deliveries/day**
- **API-first platform:** Any merchant can plug into AERLY's delivery network
- **Network effects:** Shared airspace corridors, regulatory clearances, charging hubs = defensibility
- **Margin expansion:** Software-defined infrastructure scales with near-zero marginal cost

**Revenue model evolution:**
1. **Today:** Per-delivery service fees (₹12-20)
2. **2026:** SaaS platform fees (merchants pay for API access)
3. **2028:** Airspace data licensing (route optimization IP sold to other drone operators)

---

## CONTACT

**Email:** founders@aerly.in
**Demo:** [Live Mission Control Dashboard](https://aerly.in)

**Next Steps:** Schedule 30-minute virtual demonstration (Hyderabad simulation). Review software capabilities, discuss pharmacy partnerships, and examine DGCA regulatory strategy.

---

_This brief reflects pre-operational status as of Q1 2025. Virtual demonstration system available for investor review. Regulatory environment subject to DGCA policy updates. Financials based on market analysis and industry benchmarks._
