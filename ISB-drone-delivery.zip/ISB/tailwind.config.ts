import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        aerly: {
          dark: "#0a0e1a",
          darker: "#060810",
          accent: "#00d4ff",
          success: "#00ff88",
          warning: "#ffaa00",
          danger: "#ff3366",
        },
      },
      boxShadow: {
        card: "0 4px 24px rgba(0, 212, 255, 0.08)",
        glow: "0 0 20px rgba(0, 212, 255, 0.3)",
      },
    },
  },
  plugins: [],
};
export default config;
