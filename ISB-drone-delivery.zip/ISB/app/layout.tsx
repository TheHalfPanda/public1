import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "AERLY Mission Control",
  description: "Autonomous drone delivery network - real-time operations dashboard",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
