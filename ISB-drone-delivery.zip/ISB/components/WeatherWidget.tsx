"use client";

import { WeatherCondition } from "@/lib/types";

interface WeatherWidgetProps {
  weather: WeatherCondition;
}

export default function WeatherWidget({ weather }: WeatherWidgetProps) {
  const windStatus = weather.windSpeed > 20 ? "warning" : "nominal";

  return (
    <div className="bg-white/[0.02] border border-white/10 rounded-xl p-4">
      <h3 className="text-xs font-semibold tracking-wider uppercase text-white/60 mb-4">
        WEATHER CONDITIONS
      </h3>

      <div className="grid grid-cols-2 gap-4">
        <MetricBox
          label="Wind Speed"
          value={`${weather.windSpeed.toFixed(1)} km/h`}
          status={windStatus}
        />
        <MetricBox
          label="Temperature"
          value={`${weather.temperature}°C`}
          status="nominal"
        />
        <MetricBox
          label="Visibility"
          value={`${weather.visibility} km`}
          status="nominal"
        />
        <MetricBox
          label="Conditions"
          value={weather.conditions}
          status="nominal"
        />
      </div>
    </div>
  );
}

function MetricBox({
  label,
  value,
  status,
}: {
  label: string;
  value: string;
  status: "nominal" | "warning";
}) {
  return (
    <div>
      <div className="text-[10px] text-white/40 uppercase tracking-wider mb-1">{label}</div>
      <div
        className={`text-sm font-mono font-semibold ${
          status === "warning" ? "text-aerly-warning" : "text-white"
        }`}
      >
        {value}
      </div>
    </div>
  );
}
