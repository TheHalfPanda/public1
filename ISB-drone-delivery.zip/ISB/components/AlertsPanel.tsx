"use client";

import { Alert } from "@/lib/types";
import { motion } from "framer-motion";

interface AlertsPanelProps {
  alerts: Alert[];
}

const severityConfig = {
  critical: {
    bg: "bg-aerly-danger/10",
    border: "border-aerly-danger/30",
    text: "text-aerly-danger",
    icon: "⚠",
  },
  warning: {
    bg: "bg-aerly-warning/10",
    border: "border-aerly-warning/30",
    text: "text-aerly-warning",
    icon: "⚡",
  },
  info: {
    bg: "bg-aerly-accent/10",
    border: "border-aerly-accent/30",
    text: "text-aerly-accent",
    icon: "ⓘ",
  },
};

export default function AlertsPanel({ alerts }: AlertsPanelProps) {
  const activeAlerts = alerts.filter((a) => !a.resolved);

  if (activeAlerts.length === 0) {
    return (
      <div className="bg-white/[0.02] border border-white/10 rounded-xl p-6">
        <div className="text-center">
          <div className="text-3xl mb-2">✓</div>
          <div className="text-xs font-semibold tracking-wider uppercase text-white/40">
            ALL SYSTEMS NOMINAL
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {activeAlerts.map((alert, index) => (
        <AlertCard key={alert.id} alert={alert} index={index} />
      ))}
    </div>
  );
}

function AlertCard({ alert, index }: { alert: Alert; index: number }) {
  const config = severityConfig[alert.severity];
  const timeAgo = Math.floor((Date.now() - new Date(alert.timestamp).getTime()) / 1000 / 60);

  return (
    <motion.div
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ delay: index * 0.05 }}
      className={`${config.bg} border ${config.border} rounded-xl p-4`}
    >
      <div className="flex items-start gap-3">
        <div className={`text-xl ${config.text}`}>{config.icon}</div>
        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-2 mb-1">
            <div className={`text-[10px] font-bold tracking-wider uppercase ${config.text}`}>
              {alert.category}
            </div>
            <div className="text-[10px] text-white/40">{timeAgo}m ago</div>
          </div>
          <div className="text-sm text-white leading-snug">{alert.message}</div>
          {alert.droneId && (
            <div className="mt-2 text-xs font-mono text-white/60">Drone: {alert.droneId}</div>
          )}
        </div>
      </div>
    </motion.div>
  );
}
