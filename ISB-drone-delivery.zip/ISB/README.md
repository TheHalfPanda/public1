# AERLY Mission Control

Real-time operations dashboard for autonomous drone delivery network.

## Demo Environment

**Virtual Simulation** - This is an investor demonstration system running simulated drone operations for Hyderabad Hi-Tech City area. No physical drones are currently deployed.

The simulation showcases realistic:
- Flight paths and delivery scenarios in Hi-Tech City, Gachibowli, Madhapur areas
- Pharmacy deliveries from Apollo, MedPlus, Care Hospitals
- Live no-fly zone avoidance (airports, government buildings)
- Real-time telemetry, battery management, and mission orchestration

## Quick Start

```bash
npm install
npm run dev
```

Open [http://localhost:3000](http://localhost:3000)

## Features

- **Live Fleet Tracking:** Real-time virtual drone positions, battery levels, and status
- **Delivery Management:** Active and completed delivery monitoring with detailed metrics
- **System Alerts:** Battery warnings, weather conditions, airspace restrictions
- **Economics Dashboard:** Cost savings and CO₂ impact per delivery
- **Launch Control:** Queue management and mission deployment

## Tech Stack

- Next.js 14 (App Router)
- TypeScript
- Tailwind CSS
- Framer Motion

## Project Structure

```
/app
  /api          - API routes (drones, deliveries, alerts, weather, launch)
  page.tsx      - Main dashboard
  layout.tsx    - Root layout
  globals.css   - Global styles

/components
  DroneMap.tsx              - Live airspace visualization
  FleetStats.tsx            - Fleet overview metrics
  DeliveryList.tsx          - Delivery operations panel
  DeliveryDetailDrawer.tsx  - Detailed delivery view with economics
  AlertsPanel.tsx           - System alerts and warnings
  WeatherWidget.tsx         - Weather conditions
  LaunchControl.tsx         - Mission launch interface

/lib
  types.ts          - TypeScript definitions
  mockData.ts       - Operational data (drones, deliveries, alerts, no-fly zones)
  simulateFleet.ts  - Live position updates and ETA countdown
```

## API Endpoints

- `GET /api/drones` - Fleet status with simulated position updates
- `GET /api/deliveries` - Active and completed deliveries
- `GET /api/alerts` - System alerts
- `GET /api/weather` - Current weather conditions
- `POST /api/launch` - Deploy new mission

## Deployment

Deploy to Vercel with zero configuration:

```bash
npm run build
```

## Investor Materials

See `INVESTOR_BRIEF.md` for:
- Market analysis
- Unit economics
- Regulatory strategy
- Go-to-market roadmap
- Funding requirements

---

**AERLY** — Autonomous urban drone delivery for India's metros.
