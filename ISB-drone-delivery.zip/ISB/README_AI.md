# AERLY Autonomous Fleet AI

Complete autonomous orchestration system for drone delivery operations.

## AI Architecture

### Core Systems

**1. FleetOrchestrator** (`lib/ai/fleetOrchestrator.ts`)
- Real-time fleet state management
- Autonomous decision-making every tick (2-second intervals)
- Battery optimization and emergency protocols
- Auto-assignment of deliveries to available drones

**2. Pathfinding Engine** (`lib/ai/pathfinding.ts`)
- A* pathfinding with no-fly zone avoidance
- Haversine distance calculations for accurate routing
- Dynamic waypoint generation around obstacles
- Battery consumption estimation based on distance, payload, and wind

**3. State Management**
- Singleton orchestrator instance maintains global state
- In-memory delivery queue for dynamic order creation
- Persistent state across API polling cycles

## Autonomous Capabilities

### Battery Management
- **Critical threshold (25%):** Immediate return-to-base, mission abort
- **Safe threshold (40%):** Pre-flight battery check before mission assignment
- **Minimum mission battery (45%):** Required battery to accept new deliveries
- Real-time battery drain simulation based on distance, payload weight, and wind resistance

### Auto-Assignment Logic
- Priority queue: Medical > Pharmacy > Urgent > High-Value
- Closest available drone selection
- Pre-flight battery validation (mission distance + return to base + 15% buffer)
- Automatic takeoff sequencing

### No-Fly Zone Avoidance
- Active geofencing around restricted airspaces
- Dynamic route recalculation with detour waypoints
- Real-time collision detection along flight path
- Support for temporary zones (events, government restrictions)

### Weather-Based Decisions
- Wind speed monitoring (warning threshold: 20 km/h)
- Battery penalty calculation for high-wind conditions
- Flight performance adjustments

### Alert Generation
- **Battery alerts:** Critical/warning thresholds
- **Weather alerts:** High wind conditions
- **Airspace alerts:** Active no-fly zones
- Auto-resolution when conditions normalize

## Simulation Features

### Realistic Flight Physics
- Cruise speed: 40 km/h (variance: ±4 km/h)
- Altitude: 85m cruise (±8m variance)
- Battery drain: 4% per km baseline + payload penalty + wind penalty
- Temperature increase with flight duration

### Autonomous State Transitions
```
IDLE → (auto-assign) → ASSIGNED → IN_FLIGHT → DELIVERED
                                        ↓ (low battery)
                                   RETURNING → CHARGING → IDLE
```

### Position Updates
- 2-second tick intervals
- Smooth interpolation toward waypoints
- Real-time ETA countdown
- Delivery completion detection (proximity-based)

## API Integration

All AI logic runs server-side in Next.js API routes:

- `GET /api/drones` - Returns orchestrator tick (updated positions, states)
- `GET /api/deliveries` - Returns orchestrator tick (updated ETAs, status)
- `GET /api/alerts` - Returns orchestrator tick (active alerts)
- `POST /api/launch` - Manual mission assignment via orchestrator
- `POST /api/deliveries/create` - Add new delivery to queue

## Usage

### Start the System
```bash
npm run dev
```

The orchestrator auto-initializes on first API call with:
- 1 idle drone at base (96% battery)
- 1 queued delivery
- 1 active no-fly zone (HAL Airport)

### Create New Deliveries
Use the dashboard UI "NEW DELIVERY REQUEST" button or API:

```bash
curl -X POST http://localhost:3000/api/deliveries/create \
  -H "Content-Type: application/json" \
  -d '{
    "pickup": "Apollo Pharmacy - Indiranagar",
    "dropoff": "Koramangala Residential",
    "weight": 0.4,
    "description": "Insulin vials",
    "category": "pharmacy"
  }'
```

### Watch Autonomous Operations
- **Auto-assignment:** Idle drones automatically pick up queued deliveries
- **Live tracking:** Drones move toward dropoff, avoiding no-fly zones
- **Battery management:** Low-battery drones auto-return to base
- **Alerts:** Real-time notifications for critical events

## AI Parameters (Configurable)

Edit `lib/ai/fleetOrchestrator.ts`:

```typescript
const CRITICAL_BATTERY_THRESHOLD = 25;  // Force return
const SAFE_BATTERY_THRESHOLD = 40;      // Pre-flight warning
const MIN_BATTERY_FOR_MISSION = 45;     // Accept new deliveries
const DRONE_MAX_SPEED = 45;             // km/h
const DRONE_CRUISE_SPEED = 40;          // km/h
```

## Key Algorithms

### Battery Consumption
```
consumption = (distance × 4%) + (payload_weight × 0.5%) + (wind_penalty)
wind_penalty = (windSpeed - 15) × 0.3% × distance  // if wind > 15 km/h
```

### Flight Time Estimation
```
time_minutes = (distance_km / 40_kmh) × 60
```

### Optimal Path Generation
1. Check direct path for no-fly zone intersections
2. If blocked, generate perpendicular detour waypoints
3. Validate detour safety
4. Return waypoint array for smooth navigation

## Production Considerations

For real deployment:
1. Replace in-memory state with Redis/PostgreSQL
2. Add multi-drone collision avoidance (separation distance checks)
3. Implement WebSocket for real-time updates (replace polling)
4. Add ML-based wind prediction and route optimization
5. Integrate actual DGCA airspace APIs
6. Add drone telemetry validation (GPS accuracy, sensor health)

---

**Current Status:** Fully autonomous simulation with investor-grade realism. All flight decisions made by AI without human intervention.
