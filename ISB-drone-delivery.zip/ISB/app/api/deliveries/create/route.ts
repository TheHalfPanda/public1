import { NextResponse } from "next/server";
import { addDelivery } from "@/lib/ai/deliveryQueue";
import { resetOrchestrator } from "@/lib/ai/orchestratorInstance";
import { Delivery } from "@/lib/types";
import { calculateDistance } from "@/lib/ai/pathfinding";

const PRESET_LOCATIONS: Record<string, { lat: number; lng: number }> = {
  "Apollo Pharmacy - Banjara Hills": { lat: 17.4126, lng: 78.4489 },
  "Jubilee Hills Residential": { lat: 17.4239, lng: 78.4088 },
  "Gachibowli Corporate": { lat: 17.4399, lng: 78.3489 },
  "Kukatpally Hospital": { lat: 17.4849, lng: 78.3913 },
  "Madhapur IT Hub": { lat: 17.4485, lng: 78.3908 },
  "Secunderabad Residential": { lat: 17.4399, lng: 78.4983 },
};

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { pickup, dropoff, weight, description, category } = body;

    const pickupCoords = PRESET_LOCATIONS[pickup];
    const dropoffCoords = PRESET_LOCATIONS[dropoff];

    if (!pickupCoords || !dropoffCoords) {
      return NextResponse.json({ error: "Invalid location" }, { status: 400 });
    }

    const distance = calculateDistance(pickupCoords, dropoffCoords);

    // Calculate costs
    const aerlyCost = Math.round(10 + distance * 1.5);
    const bikeCost = Math.round(25 + distance * 4.5);

    // Calculate CO2 (electric vs petrol bike)
    const aerlyEmissions = distance * 0.0025; // ~0.0025 kg CO2/km (electric + grid)
    const bikeEmissions = distance * 0.019; // ~0.019 kg CO2/km (petrol bike)

    const newDelivery: Delivery = {
      id: `DEL-${Date.now()}`,
      droneId: null,
      status: "queued",
      pickup: {
        name: pickup,
        address: pickup,
        coordinates: pickupCoords,
      },
      dropoff: {
        name: dropoff,
        address: dropoff,
        coordinates: dropoffCoords,
      },
      payload: {
        weight,
        description,
        category,
      },
      distance: parseFloat(distance.toFixed(1)),
      eta: null,
      timeOrdered: new Date().toISOString(),
      sla: 10,
      cost: {
        aerly: aerlyCost,
        bikeCourier: bikeCost,
        savings: bikeCost - aerlyCost,
      },
      co2: {
        aerly: parseFloat(aerlyEmissions.toFixed(3)),
        bikeCourier: parseFloat(bikeEmissions.toFixed(3)),
        savedKg: parseFloat((bikeEmissions - aerlyEmissions).toFixed(3)),
      },
    };

    addDelivery(newDelivery);
    resetOrchestrator(); // Force reload with new delivery

    return NextResponse.json({
      success: true,
      delivery: newDelivery,
    });
  } catch (error) {
    return NextResponse.json({ error: "Invalid request" }, { status: 400 });
  }
}
