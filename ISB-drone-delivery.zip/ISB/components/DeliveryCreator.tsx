"use client";

import { useState } from "react";
import { motion } from "framer-motion";

interface DeliveryCreatorProps {
  onCreateDelivery: (delivery: NewDeliveryRequest) => void;
}

export interface NewDeliveryRequest {
  pickup: string;
  dropoff: string;
  weight: number;
  description: string;
  category: "pharmacy" | "medical" | "urgent" | "high-value";
}

const PRESET_LOCATIONS = [
  { name: "Apollo Pharmacy - Banjara Hills", lat: 17.4126, lng: 78.4489 },
  { name: "Jubilee Hills Residential", lat: 17.4239, lng: 78.4088 },
  { name: "Gachibowli Corporate", lat: 17.4399, lng: 78.3489 },
  { name: "Kukatpally Hospital", lat: 17.4849, lng: 78.3913 },
  { name: "Madhapur IT Hub", lat: 17.4485, lng: 78.3908 },
  { name: "Secunderabad Residential", lat: 17.4399, lng: 78.4983 },
];

export default function DeliveryCreator({ onCreateDelivery }: DeliveryCreatorProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [formData, setFormData] = useState<NewDeliveryRequest>({
    pickup: "",
    dropoff: "",
    weight: 0.5,
    description: "",
    category: "pharmacy",
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onCreateDelivery(formData);
    setFormData({
      pickup: "",
      dropoff: "",
      weight: 0.5,
      description: "",
      category: "pharmacy",
    });
    setIsOpen(false);
  };

  if (!isOpen) {
    return (
      <motion.button
        onClick={() => setIsOpen(true)}
        whileHover={{ scale: 1.02 }}
        whileTap={{ scale: 0.98 }}
        className="w-full bg-aerly-accent text-aerly-dark font-semibold text-sm tracking-wider uppercase py-3 px-4 rounded-xl hover:shadow-glow transition-all"
      >
        + NEW DELIVERY REQUEST
      </motion.button>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, height: 0 }}
      animate={{ opacity: 1, height: "auto" }}
      exit={{ opacity: 0, height: 0 }}
      className="bg-white/[0.02] border border-white/10 rounded-xl p-4"
    >
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-xs font-semibold tracking-wider uppercase text-white/60">
          NEW DELIVERY
        </h3>
        <button
          onClick={() => setIsOpen(false)}
          className="text-white/40 hover:text-white/80 transition-colors"
        >
          ✕
        </button>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        {/* Pickup Location */}
        <div className="relative">
          <label className="text-[10px] text-white/40 uppercase tracking-wider mb-2 block flex items-center gap-2">
            <span className="w-5 h-5 rounded-full bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center text-[10px] shadow-lg">
              📦
            </span>
            Pickup Location
          </label>
          <div className="relative">
            <select
              value={formData.pickup}
              onChange={(e) => setFormData({ ...formData, pickup: e.target.value })}
              required
              className="w-full bg-gradient-to-br from-emerald-500/10 to-teal-600/10 border-2 border-emerald-500/30 rounded-lg px-4 py-3 text-sm text-white focus:outline-none focus:border-emerald-400 focus:shadow-[0_0_20px_rgba(16,185,129,0.3)] transition-all appearance-none pr-10"
            >
              <option value="" className="bg-aerly-dark">Select pickup location...</option>
              {PRESET_LOCATIONS.map((loc) => (
                <option key={loc.name} value={loc.name} className="bg-aerly-dark">
                  {loc.name}
                </option>
              ))}
            </select>
            <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none text-emerald-400">
              ▼
            </div>
          </div>
          {formData.pickup && (
            <div className="mt-1.5 text-[10px] text-emerald-400/60 flex items-center gap-1">
              <span>📍</span>
              <span>
                {PRESET_LOCATIONS.find(l => l.name === formData.pickup)?.lat.toFixed(4)}, {PRESET_LOCATIONS.find(l => l.name === formData.pickup)?.lng.toFixed(4)}
              </span>
            </div>
          )}
        </div>

        {/* Arrow indicator */}
        {formData.pickup && (
          <div className="flex justify-center -my-2">
            <div className="text-aerly-accent text-xl animate-bounce">↓</div>
          </div>
        )}

        {/* Dropoff Location */}
        <div className="relative">
          <label className="text-[10px] text-white/40 uppercase tracking-wider mb-2 block flex items-center gap-2">
            <span className="w-5 h-5 rounded-full bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center text-[10px] shadow-lg">
              🎯
            </span>
            Dropoff Location
          </label>
          <div className="relative">
            <select
              value={formData.dropoff}
              onChange={(e) => setFormData({ ...formData, dropoff: e.target.value })}
              required
              className="w-full bg-gradient-to-br from-blue-500/10 to-indigo-600/10 border-2 border-blue-500/30 rounded-lg px-4 py-3 text-sm text-white focus:outline-none focus:border-blue-400 focus:shadow-[0_0_20px_rgba(59,130,246,0.3)] transition-all appearance-none pr-10"
            >
              <option value="" className="bg-aerly-dark">Select dropoff location...</option>
              {PRESET_LOCATIONS.map((loc) => (
                <option key={loc.name} value={loc.name} className="bg-aerly-dark">
                  {loc.name}
                </option>
              ))}
            </select>
            <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none text-blue-400">
              ▼
            </div>
          </div>
          {formData.dropoff && (
            <div className="mt-1.5 text-[10px] text-blue-400/60 flex items-center gap-1">
              <span>📍</span>
              <span>
                {PRESET_LOCATIONS.find(l => l.name === formData.dropoff)?.lat.toFixed(4)}, {PRESET_LOCATIONS.find(l => l.name === formData.dropoff)?.lng.toFixed(4)}
              </span>
            </div>
          )}
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="text-[10px] text-white/40 uppercase tracking-wider mb-1 block">
              Weight (kg)
            </label>
            <input
              type="number"
              step="0.1"
              min="0.1"
              max="3"
              value={formData.weight}
              onChange={(e) => setFormData({ ...formData, weight: parseFloat(e.target.value) })}
              required
              className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-aerly-accent"
            />
          </div>

          <div>
            <label className="text-[10px] text-white/40 uppercase tracking-wider mb-1 block">
              Category
            </label>
            <select
              value={formData.category}
              onChange={(e) =>
                setFormData({
                  ...formData,
                  category: e.target.value as NewDeliveryRequest["category"],
                })
              }
              required
              className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-aerly-accent"
            >
              <option value="pharmacy">Pharmacy</option>
              <option value="medical">Medical</option>
              <option value="urgent">Urgent</option>
              <option value="high-value">High Value</option>
            </select>
          </div>
        </div>

        <div>
          <label className="text-[10px] text-white/40 uppercase tracking-wider mb-1 block">
            Description
          </label>
          <input
            type="text"
            value={formData.description}
            onChange={(e) => setFormData({ ...formData, description: e.target.value })}
            placeholder="e.g. Insulin vials (temperature controlled)"
            required
            className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-white placeholder:text-white/30 focus:outline-none focus:border-aerly-accent"
          />
        </div>

        <motion.button
          type="submit"
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          className="w-full bg-gradient-to-r from-aerly-accent to-cyan-400 text-aerly-dark font-bold text-sm tracking-wider uppercase py-3.5 px-4 rounded-lg hover:shadow-[0_0_30px_rgba(0,212,255,0.5)] transition-all relative overflow-hidden group"
        >
          <span className="relative z-10 flex items-center justify-center gap-2">
            <span>✓</span>
            CREATE & QUEUE DELIVERY
          </span>
          <div className="absolute inset-0 bg-gradient-to-r from-cyan-400 to-aerly-accent opacity-0 group-hover:opacity-100 transition-opacity" />
        </motion.button>
      </form>
    </motion.div>
  );
}
