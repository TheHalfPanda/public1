"use client";

import { Delivery } from "@/lib/types";
import { motion } from "framer-motion";
import { useState } from "react";

interface LaunchControlProps {
  queuedDeliveries: Delivery[];
  onLaunch: (deliveryId: string) => void;
}

export default function LaunchControl({ queuedDeliveries, onLaunch }: LaunchControlProps) {
  const [launching, setLaunching] = useState(false);

  const handleLaunch = async (deliveryId: string) => {
    setLaunching(true);
    try {
      await onLaunch(deliveryId);
    } finally {
      setTimeout(() => setLaunching(false), 1500);
    }
  };

  if (queuedDeliveries.length === 0) {
    return (
      <div className="bg-white/[0.02] border border-white/10 rounded-xl p-6 text-center">
        <div className="text-white/40 text-sm">No deliveries in queue</div>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {queuedDeliveries.map((delivery) => (
        <div
          key={delivery.id}
          className="bg-white/[0.02] border border-white/10 rounded-xl p-4 flex items-center justify-between"
        >
          <div className="flex-1">
            <div className="text-sm font-mono font-semibold text-white">{delivery.id}</div>
            <div className="text-xs text-white/60 mt-1">{delivery.payload.description}</div>
          </div>
          <motion.button
            onClick={() => handleLaunch(delivery.id)}
            disabled={launching}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className={`px-4 py-2 rounded-lg font-semibold text-xs tracking-wider uppercase transition-all ${
              launching
                ? "bg-gray-600 text-white/40 cursor-not-allowed"
                : "bg-aerly-accent text-aerly-dark hover:shadow-glow"
            }`}
          >
            {launching ? "LAUNCHING..." : "LAUNCH"}
          </motion.button>
        </div>
      ))}
    </div>
  );
}
