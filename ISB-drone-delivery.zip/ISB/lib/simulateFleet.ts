import { Drone, Delivery } from "./types";

/**
 * Simulates realistic drone position changes for live tracking
 */
export function simulateDroneMovement(drone: Drone, delivery?: Delivery): Drone {
  if (drone.status === "idle" || drone.status === "charging") {
    return drone;
  }

  const mutated = { ...drone };

  // Slight position drift for en_route drones
  if (drone.status === "en_route" && delivery) {
    const { lat: targetLat, lng: targetLng } = delivery.dropoff.coordinates;
    const deltaLat = (targetLat - drone.position.lat) * 0.02;
    const deltaLng = (targetLng - drone.position.lng) * 0.02;

    mutated.position = {
      lat: drone.position.lat + deltaLat + (Math.random() - 0.5) * 0.0002,
      lng: drone.position.lng + deltaLng + (Math.random() - 0.5) * 0.0002,
    };

    // Battery drain
    mutated.battery = Math.max(15, drone.battery - Math.random() * 0.3);

    // Slight speed variance
    mutated.speed = Math.max(30, Math.min(45, drone.speed + (Math.random() - 0.5) * 2));

    // Temperature drift
    mutated.temperature = Math.max(38, Math.min(48, drone.temperature + (Math.random() - 0.5) * 1));
  }

  // Returning drones move toward base (Hi-Tech City base)
  if (drone.status === "returning") {
    const baseLat = 17.4435;  // Hi-Tech City, Hyderabad
    const baseLng = 78.3772;
    const deltaLat = (baseLat - drone.position.lat) * 0.03;
    const deltaLng = (baseLng - drone.position.lng) * 0.03;

    mutated.position = {
      lat: drone.position.lat + deltaLat,
      lng: drone.position.lng + deltaLng,
    };

    mutated.battery = Math.max(15, drone.battery - Math.random() * 0.4);
    mutated.speed = Math.max(25, Math.min(40, drone.speed + (Math.random() - 0.5) * 3));
  }

  return mutated;
}

/**
 * Updates ETA countdown for active deliveries
 */
export function updateDeliveryETA(delivery: Delivery): Delivery {
  if (delivery.status !== "in_flight" || !delivery.eta) {
    return delivery;
  }

  const [minutes, seconds] = delivery.eta.split("m ");
  const totalSeconds = parseInt(minutes) * 60 + parseInt(seconds.replace("s", ""));

  if (totalSeconds <= 2) {
    return delivery;
  }

  const newTotal = Math.max(0, totalSeconds - 2);
  const newMinutes = Math.floor(newTotal / 60);
  const newSeconds = newTotal % 60;

  return {
    ...delivery,
    eta: `${newMinutes}m ${newSeconds}s`,
  };
}
