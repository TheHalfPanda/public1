import { NextResponse } from "next/server";
import { getOrchestrator } from "@/lib/ai/orchestratorInstance";
import { findPathAStar, simplifyPath, smoothPath } from "@/lib/ai/astar";
import { noFlyZones } from "@/lib/mockData";

/**
 * Upload A* computed mission to real drone hardware
 * POST /api/hardware/mission
 */

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { droneId, deliveryId } = body;

    const orchestrator = getOrchestrator();
    const result = orchestrator.tick();

    const drone = result.drones.find((d) => d.id === droneId);
    const delivery = result.deliveries.find((d) => d.id === deliveryId);

    if (!drone || !delivery) {
      return NextResponse.json({ error: "Drone or delivery not found" }, { status: 404 });
    }

    // Compute A* path
    const astarResult = findPathAStar(
      delivery.pickup.coordinates,
      delivery.dropoff.coordinates,
      noFlyZones
    );

    // Smooth and simplify for flight
    const smoothedPath = smoothPath(astarResult.path, 2);
    const finalPath = simplifyPath(smoothedPath, 0.0002);

    console.log(`[Hardware] Computed mission: ${finalPath.length} waypoints, ${astarResult.nodesExplored} nodes explored`);

    // In production with real hardware:
    // const mavlink = getMAVLinkInstance();
    // await mavlink.uploadMission(finalPath);
    // await mavlink.arm();
    // await mavlink.startMission();

    return NextResponse.json({
      success: true,
      message: "Mission uploaded to drone",
      waypoints: finalPath,
      nodesExplored: astarResult.nodesExplored,
      distance: astarResult.cost,
    });
  } catch (error) {
    console.error("Mission upload error:", error);
    return NextResponse.json({ error: "Mission upload failed" }, { status: 500 });
  }
}
