"use client";

import { useEffect, useRef, useState } from "react";
import { Coordinates, NoFlyZone } from "@/lib/types";
import { findPathAStar } from "@/lib/ai/astar";
import { motion } from "framer-motion";

interface AlgorithmVisualizerProps {
  start?: Coordinates;
  goal?: Coordinates;
  noFlyZones: NoFlyZone[];
}

export default function AlgorithmVisualizer({
  start,
  goal,
  noFlyZones,
}: AlgorithmVisualizerProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isComputing, setIsComputing] = useState(false);
  const [stats, setStats] = useState<{
    nodesExplored: number;
    pathLength: number;
    computeTime: number;
  } | null>(null);

  useEffect(() => {
    if (!canvasRef.current || !start || !goal) return;

    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    // Set canvas size
    canvas.width = 800;
    canvas.height = 600;

    // Clear canvas
    ctx.fillStyle = "#0a0e1a";
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Grid overlay
    ctx.strokeStyle = "rgba(0, 212, 255, 0.05)";
    ctx.lineWidth = 1;
    for (let x = 0; x < canvas.width; x += 40) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, canvas.height);
      ctx.stroke();
    }
    for (let y = 0; y < canvas.height; y += 40) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(canvas.width, y);
      ctx.stroke();
    }

    // Coordinate mapping (Hyderabad bounds to canvas)
    const mapCoords = (coords: Coordinates) => {
      const latRange = [17.25, 17.55];
      const lngRange = [78.35, 78.65];

      const x = ((coords.lng - lngRange[0]) / (lngRange[1] - lngRange[0])) * canvas.width;
      const y = ((latRange[1] - coords.lat) / (latRange[1] - latRange[0])) * canvas.height;

      return { x, y };
    };

    // Draw no-fly zones
    noFlyZones.forEach((zone) => {
      if (!zone.active) return;

      const pos = mapCoords(zone.coordinates);
      const radiusPx = (zone.radius / 1000) * 30; // Approximate scaling

      ctx.fillStyle = "rgba(255, 51, 102, 0.15)";
      ctx.beginPath();
      ctx.arc(pos.x, pos.y, radiusPx, 0, 2 * Math.PI);
      ctx.fill();

      ctx.strokeStyle = "rgba(255, 51, 102, 0.5)";
      ctx.lineWidth = 2;
      ctx.stroke();

      // Label
      ctx.font = "10px monospace";
      ctx.fillStyle = "#ff3366";
      ctx.fillText(zone.name.split(" ")[0], pos.x + radiusPx + 5, pos.y);
    });

    // Run A* algorithm
    setIsComputing(true);
    const startTime = performance.now();

    const result = findPathAStar(start, goal, noFlyZones);

    const endTime = performance.now();

    setStats({
      nodesExplored: result.nodesExplored,
      pathLength: result.path.length,
      computeTime: endTime - startTime,
    });

    // Visualize explored nodes (closed set)
    ctx.fillStyle = "rgba(0, 212, 255, 0.1)";
    result.closedSet.forEach((coords) => {
      const pos = mapCoords(coords);
      ctx.fillRect(pos.x - 2, pos.y - 2, 4, 4);
    });

    // Visualize open set
    ctx.fillStyle = "rgba(255, 170, 0, 0.2)";
    result.openSet.forEach((coords) => {
      const pos = mapCoords(coords);
      ctx.fillRect(pos.x - 2, pos.y - 2, 4, 4);
    });

    // Draw final path
    ctx.strokeStyle = "#00ff88";
    ctx.lineWidth = 3;
    ctx.setLineDash([]);
    ctx.beginPath();

    result.path.forEach((coords, idx) => {
      const pos = mapCoords(coords);
      if (idx === 0) {
        ctx.moveTo(pos.x, pos.y);
      } else {
        ctx.lineTo(pos.x, pos.y);
      }
    });

    ctx.stroke();

    // Draw waypoint markers
    result.path.forEach((coords, idx) => {
      const pos = mapCoords(coords);

      ctx.fillStyle = "#00ff88";
      ctx.beginPath();
      ctx.arc(pos.x, pos.y, 4, 0, 2 * Math.PI);
      ctx.fill();

      // Waypoint number
      if (idx % 5 === 0) {
        ctx.font = "10px monospace";
        ctx.fillStyle = "#00ff88";
        ctx.fillText(`#${idx}`, pos.x + 6, pos.y - 6);
      }
    });

    // Draw start point
    const startPos = mapCoords(start);
    ctx.fillStyle = "#00d4ff";
    ctx.beginPath();
    ctx.arc(startPos.x, startPos.y, 8, 0, 2 * Math.PI);
    ctx.fill();

    ctx.font = "12px monospace";
    ctx.fillStyle = "#00d4ff";
    ctx.fillText("START", startPos.x + 12, startPos.y);

    // Draw goal point
    const goalPos = mapCoords(goal);
    ctx.fillStyle = "#ff3366";
    ctx.beginPath();
    ctx.arc(goalPos.x, goalPos.y, 8, 0, 2 * Math.PI);
    ctx.fill();

    ctx.font = "12px monospace";
    ctx.fillStyle = "#ff3366";
    ctx.fillText("GOAL", goalPos.x + 12, goalPos.y);

    setIsComputing(false);
  }, [start, goal, noFlyZones]);

  return (
    <div className="bg-white/[0.02] border border-white/10 rounded-xl p-4">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-xs font-semibold tracking-wider uppercase text-white/60">
          A* ALGORITHM VISUALIZATION
        </h3>
        {isComputing && (
          <div className="text-xs text-aerly-accent animate-pulse">COMPUTING...</div>
        )}
      </div>

      <canvas
        ref={canvasRef}
        className="w-full h-auto bg-aerly-darker rounded-lg"
        style={{ maxHeight: "400px" }}
      />

      {stats && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="mt-4 grid grid-cols-3 gap-3"
        >
          <div className="p-3 bg-white/[0.02] border border-white/10 rounded-lg">
            <div className="text-[10px] text-white/40 uppercase tracking-wider mb-1">
              Nodes Explored
            </div>
            <div className="text-lg font-mono font-bold text-aerly-accent">
              {stats.nodesExplored}
            </div>
          </div>

          <div className="p-3 bg-white/[0.02] border border-white/10 rounded-lg">
            <div className="text-[10px] text-white/40 uppercase tracking-wider mb-1">
              Path Waypoints
            </div>
            <div className="text-lg font-mono font-bold text-aerly-success">
              {stats.pathLength}
            </div>
          </div>

          <div className="p-3 bg-white/[0.02] border border-white/10 rounded-lg">
            <div className="text-[10px] text-white/40 uppercase tracking-wider mb-1">
              Compute Time
            </div>
            <div className="text-lg font-mono font-bold text-white">
              {stats.computeTime.toFixed(1)}ms
            </div>
          </div>
        </motion.div>
      )}

      <div className="mt-4 p-3 bg-aerly-accent/5 border border-aerly-accent/20 rounded-lg">
        <div className="text-[10px] text-aerly-accent font-semibold mb-2">LEGEND</div>
        <div className="grid grid-cols-2 gap-2 text-[10px] text-white/60">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-[rgba(0,212,255,0.1)] border border-[rgba(0,212,255,0.3)]" />
            Explored Nodes
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-[rgba(255,170,0,0.2)] border border-[rgba(255,170,0,0.3)]" />
            Open Set
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-[#00ff88]" />
            Optimal Path
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-[rgba(255,51,102,0.15)] border border-[rgba(255,51,102,0.5)]" />
            No-Fly Zones
          </div>
        </div>
      </div>
    </div>
  );
}
