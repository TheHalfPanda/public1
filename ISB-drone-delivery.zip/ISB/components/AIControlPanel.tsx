"use client";

import { motion } from "framer-motion";

interface AIControlPanelProps {
  autoAssignments: number;
  isAIActive: boolean;
}

export default function AIControlPanel({ autoAssignments, isAIActive }: AIControlPanelProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-gradient-to-br from-aerly-accent/10 to-aerly-success/10 border border-aerly-accent/30 rounded-xl p-4"
    >
      <div className="flex items-start justify-between mb-4">
        <div>
          <h3 className="text-xs font-semibold tracking-wider uppercase text-white/60">
            AUTONOMOUS ORCHESTRATION
          </h3>
          <div className="flex items-center gap-2 mt-2">
            <div
              className={`w-2 h-2 rounded-full ${
                isAIActive ? "bg-aerly-success animate-pulse" : "bg-gray-500"
              }`}
            />
            <span className="text-sm font-mono text-white">
              {isAIActive ? "ACTIVE" : "STANDBY"}
            </span>
          </div>
        </div>

        <div className="text-right">
          <div className="text-[10px] text-white/40 uppercase tracking-wider">AI Assignments</div>
          <div className="text-2xl font-mono font-bold text-aerly-accent">{autoAssignments}</div>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3 pt-3 border-t border-white/10">
        <CapabilityIndicator label="Pathfinding" active />
        <CapabilityIndicator label="Battery Mgmt" active />
        <CapabilityIndicator label="No-Fly Avoid" active />
        <CapabilityIndicator label="Priority Queue" active />
      </div>
    </motion.div>
  );
}

function CapabilityIndicator({ label, active }: { label: string; active: boolean }) {
  return (
    <div className="flex items-center gap-2">
      <div className={`w-1.5 h-1.5 rounded-full ${active ? "bg-aerly-success" : "bg-gray-500"}`} />
      <span className="text-[10px] text-white/70">{label}</span>
    </div>
  );
}
