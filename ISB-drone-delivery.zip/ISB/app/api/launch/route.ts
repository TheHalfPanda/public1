import { NextResponse } from "next/server";
import { getOrchestrator } from "@/lib/ai/orchestratorInstance";

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { deliveryId } = body;

    const orchestrator = getOrchestrator();
    const result = orchestrator.assignDelivery(deliveryId);

    if (!result.success) {
      return NextResponse.json({ error: result.error }, { status: 400 });
    }

    return NextResponse.json({
      success: true,
      message: "Mission launched successfully",
    });
  } catch (error) {
    return NextResponse.json({ error: "Invalid request" }, { status: 400 });
  }
}
