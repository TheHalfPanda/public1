import { NextResponse } from "next/server";
import { weather } from "@/lib/mockData";

export async function GET() {
  // Slight wind variance for realism
  const variantWeather = {
    ...weather,
    windSpeed: Math.max(12, Math.min(25, weather.windSpeed + (Math.random() - 0.5) * 2)),
  };

  return NextResponse.json({ weather: variantWeather });
}
