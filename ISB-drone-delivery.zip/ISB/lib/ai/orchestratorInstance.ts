import { FleetOrchestrator } from "./fleetOrchestrator";
import { drones, deliveries, noFlyZones, weather, alerts } from "../mockData";
import { getDeliveries } from "./deliveryQueue";

/**
 * Global singleton orchestrator instance
 * Maintains state across API calls
 */

let orchestratorInstance: FleetOrchestrator | null = null;

export function getOrchestrator(): FleetOrchestrator {
  if (!orchestratorInstance) {
    // Merge initial deliveries with dynamically created ones
    const allDeliveries = [...deliveries, ...getDeliveries()];

    orchestratorInstance = new FleetOrchestrator(
      [...drones],
      allDeliveries,
      [...noFlyZones],
      { ...weather },
      [...alerts]
    );
  }
  return orchestratorInstance;
}

export function resetOrchestrator(): void {
  orchestratorInstance = null;
}
