# Real-Time Video Streaming & Algorithm Visualization

Complete guide to streaming live drone camera feed with AI algorithm overlay for investor demos.

## Video Streaming Protocols

### 1. MJPEG (Easiest - Start Here)
**Best for:** Quick demo setup, low technical complexity

**Hardware:** ESP32-CAM module (₹500-800)

**Setup:**
```bash
# Flash ESP32-CAM with MJPEG streaming firmware
# Arduino IDE → Examples → ESP32 → Camera → CameraWebServer

# Configure WiFi in code:
const char* ssid = "your-wifi-name";
const char* password = "your-wifi-password";

# Upload to ESP32-CAM
# Get IP address from serial monitor (e.g., 192.168.1.100)

# Dashboard: CONFIGURE STREAM
# Protocol: MJPEG
# URL: http://192.168.1.100:81/stream
```

**Pros:**
- Works directly in browser
- No transcoding needed
- Under ₹1000 total cost

**Cons:**
- Higher latency (~500-800ms)
- More bandwidth usage

---

### 2. WebRTC (Best for Production)
**Best for:** Low latency (<200ms), professional demos

**Hardware:** Raspberry Pi 4 + Camera Module v2 (₹8000-10000)

**Setup:**
```bash
# On Raspberry Pi
sudo apt-get install gstreamer1.0-tools gstreamer1.0-plugins-good

# Install aiortc (Python WebRTC library)
pip3 install aiortc opencv-python

# Create server.py:
from aiortc import RTCPeerConnection, RTCSessionDescription, VideoStreamTrack
from aiohttp import web
import cv2

class CameraTrack(VideoStreamTrack):
    def __init__(self):
        super().__init__()
        self.cap = cv2.VideoCapture(0)

    async def recv(self):
        frame = self.cap.read()[1]
        return av.VideoFrame.from_ndarray(frame, format="bgr24")

async def offer(request):
    params = await request.json()
    pc = RTCPeerConnection()
    pc.addTrack(CameraTrack())

    await pc.setRemoteDescription(RTCSessionDescription(**params))
    answer = await pc.createAnswer()
    await pc.setLocalDescription(answer)

    return web.json_response({
        "sdp": pc.localDescription.sdp,
        "type": pc.localDescription.type
    })

app = web.Application()
app.router.add_post('/offer', offer)
web.run_app(app, host='0.0.0.0', port=8080)

# Run: python3 server.py

# Dashboard: CONFIGURE STREAM
# Protocol: WebRTC
# URL: http://pi-ip:8080/offer
```

**Pros:**
- Ultra-low latency (~100-300ms)
- Adaptive bitrate
- Industry standard

**Cons:**
- Requires backend server
- More complex setup

---

### 3. HLS (HTTP Live Streaming)
**Best for:** Recording + live streaming combo

**Setup:**
```bash
# On drone companion computer (Raspberry Pi)
sudo apt-get install ffmpeg

# Stream to HLS
ffmpeg -f v4l2 -i /dev/video0 \
  -c:v libx264 -preset ultrafast -tune zerolatency \
  -f hls -hls_time 1 -hls_list_size 3 \
  /var/www/html/stream.m3u8

# Dashboard: CONFIGURE STREAM
# Protocol: HLS
# URL: http://pi-ip/stream.m3u8
```

**Pros:**
- Widely supported
- Can record simultaneously
- HTTP-based (firewall-friendly)

**Cons:**
- Higher latency (3-10 seconds)
- Requires web server

---

## Algorithm Visualization Overlay

### Real-Time Telemetry HUD
Automatically overlaid on video feed:

**Top-Left Corner:**
```
┌─────────────────┐
│ ALT: 85.3m      │
│ SPD: 12.5 m/s   │
│ BAT: 87%        │
│ HDG: 245°       │
└─────────────────┘
```

**Bottom Section:**
```
A* PATH: 12 waypoints
─────────●─────●─────●─────●─────
```

**Center:**
```
      ◉  ← Drone position crosshair
```

**Bottom-Right:**
```
AERLY AUTONOMOUS
```

### Standalone A* Visualizer

Separate panel showing algorithm internals:

**Canvas Elements:**
- **Blue dots:** Explored nodes (closed set)
- **Orange dots:** Frontier nodes (open set)
- **Green line:** Optimal path
- **Red circles:** No-fly zones
- **Cyan circle:** Start point
- **Red circle:** Goal point

**Stats Display:**
- Nodes Explored: 87
- Path Waypoints: 12
- Compute Time: 3.2ms

---

## Hardware Recommendations

### Budget Setup (₹1000-2000)
**ESP32-CAM**
- Resolution: 1600×1200
- Frame rate: 10-15 fps
- Protocol: MJPEG
- Latency: ~500ms
- Mount on drone with USB power bank

### Mid-Range (₹8000-12000)
**Raspberry Pi Zero 2 W + Camera Module v2**
- Resolution: 1920×1080
- Frame rate: 30 fps
- Protocol: WebRTC or HLS
- Latency: ~200ms
- Powered by drone's battery (5V BEC)

### Professional (₹25000+)
**Raspberry Pi 4 + HQ Camera + Wide-Angle Lens**
- Resolution: 4056×3040
- Frame rate: 60 fps (downscaled to 1080p30)
- Protocol: WebRTC
- Latency: <150ms
- H.264 hardware encoding

### Premium (₹50000+)
**DJI Air Unit or Caddx Vista**
- Resolution: 1920×1080
- Frame rate: 60 fps
- Protocol: Digital FPV (requires custom integration)
- Latency: <40ms
- Professional stabilization

---

## Physical Mounting

### Gimbal-Free Fixed Mount
```
    ┌─────────────┐
    │   Camera    │  ← 15-20° down angle
    └─────────────┘
         ↓
    ┌─────────────┐
    │   Drone     │
    │   Frame     │
    └─────────────┘
```

**Advantages:**
- No extra weight
- No power draw
- Cheaper

**Disadvantages:**
- Shakier footage
- Fixed angle

### 2-Axis Gimbal
```
         Camera
           ↓
      ╔═══╗ ← Pitch servo
      ║   ║
      ╚═══╝
         ↓
      ╔═══╗ ← Roll servo
      ║   ║
      ╚═══╝
```

**Advantages:**
- Smooth footage
- Dynamic angle control

**Disadvantages:**
- +150-300g weight
- +5-10W power draw
- ₹8000-15000 cost

---

## Network Setup

### Drone WiFi Configuration

**Option 1: Drone creates hotspot**
```bash
# On Raspberry Pi
sudo apt-get install hostapd dnsmasq

# Configure /etc/hostapd/hostapd.conf:
interface=wlan0
ssid=AERLY-DRONE-01
wpa_passphrase=aerly2025
hw_mode=g
channel=6

# Ground station laptop connects to "AERLY-DRONE-01"
# Stream URL: http://10.0.0.1:8080/offer
```

**Option 2: Both connect to existing WiFi**
```bash
# Drone and ground station on same network
# Drone IP: 192.168.1.100
# Stream URL: http://192.168.1.100:8080/offer
```

**Range:**
- 2.4GHz WiFi: ~100-150m outdoor
- 5GHz WiFi: ~50-80m outdoor (faster but shorter range)
- 4G LTE (with SIM): Unlimited range (higher latency)

---

## Investor Demo Setup

### Pre-Flight Checklist

1. **Hardware:**
   - [ ] Camera powered and mounted
   - [ ] WiFi connection established
   - [ ] Stream tested from ground

2. **Software:**
   - [ ] Dashboard open at http://localhost:3000
   - [ ] Video stream configured and connected
   - [ ] Telemetry overlay enabled
   - [ ] A* visualizer showing path

3. **Delivery:**
   - [ ] Create delivery (Banjara Hills → Jubilee Hills)
   - [ ] Verify A* path avoids Begumpet Airport
   - [ ] Upload mission to drone
   - [ ] Arm and start mission

### During Demo

**Dashboard Layout:**
```
┌─────────────────────────────────────┬──────────────┐
│  LIVE CAMERA FEED                   │  DELIVERY    │
│  ┌─────────────────────────────┐    │  LIST        │
│  │                             │    │              │
│  │  [Live Video with Overlay]  │    │  DEL-1001    │
│  │                             │    │  ● QUEUED    │
│  │  ALT: 85m  SPD: 12m/s      │    │              │
│  │  BAT: 87%  HDG: 245°       │    │  DEL-1002    │
│  │                             │    │  ✓ DELIVERED │
│  │  A* PATH: ●───●───●───●    │    │              │
│  └─────────────────────────────┘    │              │
├─────────────────────────────────────┤              │
│  LIVE AIRSPACE (MAP)                │              │
│  [Drone moving on A* path]          │              │
├─────────────────────────────────────┤              │
│  A* ALGORITHM VISUALIZATION         │              │
│  [Canvas showing pathfinding]       │              │
│  Nodes: 87  Time: 3.2ms             │              │
└─────────────────────────────────────┴──────────────┘
```

**Talking Points:**
1. "This is live camera feed from our drone over Hyderabad"
2. "The green line shows the AI-computed optimal path"
3. "Notice how it automatically avoids Begumpet Airport no-fly zone"
4. "Real-time telemetry: altitude, speed, battery overlaid on video"
5. "Bottom panel shows A* algorithm in action - explored 87 nodes in 3ms"
6. "This same AI will run on thousands of drones simultaneously"

---

## Troubleshooting

### No Video Feed
```bash
# Check camera is detected
ls /dev/video*  # Should show /dev/video0

# Test with VLC
vlc v4l2:///dev/video0

# Check network connectivity
ping drone-ip

# Verify firewall allows port
sudo ufw allow 8080/tcp
```

### High Latency
- Switch to WebRTC from MJPEG
- Reduce resolution (1080p → 720p)
- Lower frame rate (30fps → 20fps)
- Check WiFi signal strength

### Choppy Video
- Enable H.264 hardware encoding on Pi
- Reduce bitrate in stream config
- Use wired connection instead of WiFi

### Overlay Not Showing
- Check `showOverlay={true}` prop
- Verify telemetry data is present
- Canvas size matches video dimensions

---

## Advanced: Real-Time Recording

Record video with overlay for post-demo analysis:

```typescript
// Add to VideoStream component
const mediaRecorder = new MediaRecorder(canvasStream, {
  mimeType: 'video/webm;codecs=vp8',
  videoBitsPerSecond: 2500000
});

const chunks: Blob[] = [];

mediaRecorder.ondataavailable = (e) => chunks.push(e.data);
mediaRecorder.onstop = () => {
  const blob = new Blob(chunks, { type: 'video/webm' });
  const url = URL.createObjectURL(blob);

  const a = document.createElement('a');
  a.href = url;
  a.download = `aerly-mission-${Date.now()}.webm`;
  a.click();
};

// Start recording
mediaRecorder.start();

// Stop after mission complete
mediaRecorder.stop();
```

Result: `aerly-mission-1234567890.webm` with full telemetry overlay.

---

## Cost Breakdown

| Component | Budget | Mid-Range | Professional |
|-----------|--------|-----------|--------------|
| Camera | ESP32-CAM ₹700 | Pi Zero 2 + Cam ₹4000 | Pi 4 + HQ Cam ₹15000 |
| Mount | 3D printed ₹100 | 3D printed ₹100 | 2-Axis Gimbal ₹12000 |
| Power | USB bank ₹500 | BEC 5V ₹300 | Dedicated battery ₹2000 |
| **Total** | **₹1300** | **₹4400** | **₹29000** |

**Recommendation for Investor Demo:** Mid-range (₹4400) provides excellent quality-to-cost ratio.

---

**Current Status:** Full video streaming + algorithm visualization ready. Connect ESP32-CAM or Raspberry Pi, configure stream URL, watch live drone flight with real-time A* path overlay.

