"use client";

import { Drone } from "@/lib/types";
import { motion } from "framer-motion";

interface FleetStatsProps {
  drones: Drone[];
}

export default function FleetStats({ drones }: FleetStatsProps) {
  const active = drones.filter((d) => d.status === "en_route").length;
  const idle = drones.filter((d) => d.status === "idle").length;
  const charging = drones.filter((d) => d.status === "charging").length;
  const avgBattery = Math.round(
    drones.reduce((sum, d) => sum + d.battery, 0) / drones.length
  );

  return (
    <div className="grid grid-cols-4 gap-4">
      <StatCard label="ACTIVE" value={active} color="text-aerly-accent" />
      <StatCard label="IDLE" value={idle} color="text-white" />
      <StatCard label="CHARGING" value={charging} color="text-aerly-warning" />
      <StatCard label="AVG BATTERY" value={`${avgBattery}%`} color="text-aerly-success" />
    </div>
  );
}

function StatCard({
  label,
  value,
  color,
}: {
  label: string;
  value: number | string;
  color: string;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white/[0.02] border border-white/10 rounded-xl p-4"
    >
      <div className="text-[10px] text-white/40 uppercase tracking-wider mb-2">{label}</div>
      <div className={`text-2xl font-mono font-bold ${color}`}>{value}</div>
    </motion.div>
  );
}
