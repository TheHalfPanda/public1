/**
 * Real-Time Video Streaming from Drone Camera
 * Supports WebRTC, RTSP, MJPEG protocols
 */

export type VideoProtocol = "webrtc" | "rtsp" | "mjpeg" | "hls";

export interface VideoStreamConfig {
  protocol: VideoProtocol;
  url: string;
  resolution?: { width: number; height: number };
  bitrate?: number;
  fps?: number;
}

export interface VideoStreamStats {
  fps: number;
  bitrate: number;
  latency: number;
  packetsLost: number;
  timestamp: number;
}

/**
 * Drone Video Stream Manager
 */
export class DroneVideoStream {
  private config: VideoStreamConfig;
  private videoElement: HTMLVideoElement | null = null;
  private stream: MediaStream | null = null;
  private stats: VideoStreamStats = {
    fps: 0,
    bitrate: 0,
    latency: 0,
    packetsLost: 0,
    timestamp: Date.now(),
  };

  constructor(config: VideoStreamConfig) {
    this.config = config;
  }

  /**
   * Start video stream
   */
  async start(videoElement: HTMLVideoElement): Promise<boolean> {
    this.videoElement = videoElement;

    console.log(`[Video] Starting ${this.config.protocol} stream from ${this.config.url}`);

    switch (this.config.protocol) {
      case "webrtc":
        return this.startWebRTC();
      case "rtsp":
        return this.startRTSP();
      case "mjpeg":
        return this.startMJPEG();
      case "hls":
        return this.startHLS();
      default:
        console.error("[Video] Unsupported protocol");
        return false;
    }
  }

  /**
   * Stop video stream
   */
  stop(): void {
    if (this.stream) {
      this.stream.getTracks().forEach((track) => track.stop());
      this.stream = null;
    }

    if (this.videoElement) {
      this.videoElement.srcObject = null;
      this.videoElement.src = "";
    }

    console.log("[Video] Stream stopped");
  }

  /**
   * Get current stream statistics
   */
  getStats(): VideoStreamStats {
    return this.stats;
  }

  /**
   * WebRTC streaming (lowest latency ~100-300ms)
   * Requires: Companion computer running WebRTC server (e.g., aiortc, Janus)
   */
  private async startWebRTC(): Promise<boolean> {
    try {
      // WebRTC peer connection setup
      const pc = new RTCPeerConnection({
        iceServers: [{ urls: "stun:stun.l.google.com:19302" }],
      });

      // Request video stream from drone
      const response = await fetch(this.config.url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ type: "offer" }),
      });

      const { sdp } = await response.json();
      await pc.setRemoteDescription(new RTCSessionDescription(sdp));

      const answer = await pc.createAnswer();
      await pc.setLocalDescription(answer);

      // Send answer back to drone
      await fetch(this.config.url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ type: "answer", sdp: answer.sdp }),
      });

      // Attach stream to video element
      pc.ontrack = (event) => {
        if (this.videoElement && event.streams[0]) {
          this.videoElement.srcObject = event.streams[0];
          this.stream = event.streams[0];
        }
      };

      // Monitor connection stats
      this.monitorWebRTCStats(pc);

      console.log("[Video] WebRTC stream started");
      return true;
    } catch (error) {
      console.error("[Video] WebRTC failed:", error);
      return false;
    }
  }

  /**
   * RTSP streaming (common with IP cameras)
   * Requires: Backend proxy (ffmpeg converting RTSP → HLS/WebRTC)
   */
  private async startRTSP(): Promise<boolean> {
    console.log("[Video] RTSP requires backend transcoding");
    console.log("[Video] Use: ffmpeg -i rtsp://drone:8554/live -f hls output.m3u8");

    // In production: Backend converts RTSP to browser-compatible format
    // For now, show placeholder
    return false;
  }

  /**
   * MJPEG streaming (high latency ~500-1000ms but simple)
   * Works directly in browser
   */
  private async startMJPEG(): Promise<boolean> {
    if (!this.videoElement) return false;

    // MJPEG can be displayed directly as image source
    this.videoElement.src = this.config.url;

    console.log("[Video] MJPEG stream started");
    return true;
  }

  /**
   * HLS streaming (Apple HTTP Live Streaming)
   * Good for recorded/delayed streams
   */
  private async startHLS(): Promise<boolean> {
    if (!this.videoElement) return false;

    // Check for native HLS support (Safari)
    if (this.videoElement.canPlayType("application/vnd.apple.mpegurl")) {
      this.videoElement.src = this.config.url;
      await this.videoElement.play();
      return true;
    }

    // Use hls.js for other browsers
    if (typeof window !== "undefined" && "Hls" in window) {
      const Hls = (window as any).Hls;
      const hls = new Hls();
      hls.loadSource(this.config.url);
      hls.attachMedia(this.videoElement);

      console.log("[Video] HLS stream started");
      return true;
    }

    console.error("[Video] HLS not supported");
    return false;
  }

  /**
   * Monitor WebRTC statistics
   */
  private monitorWebRTCStats(pc: RTCPeerConnection): void {
    setInterval(async () => {
      const stats = await pc.getStats();

      stats.forEach((report) => {
        if (report.type === "inbound-rtp" && report.mediaType === "video") {
          this.stats = {
            fps: report.framesPerSecond || 0,
            bitrate: report.bytesReceived || 0,
            latency: report.jitter || 0,
            packetsLost: report.packetsLost || 0,
            timestamp: Date.now(),
          };
        }
      });
    }, 1000);
  }
}

/**
 * Recommended hardware setups:
 *
 * 1. Raspberry Pi 4 + Camera Module v2
 *    - Run: libcamera-vid -t 0 --inline -o - | cvlc -vvv stream:///dev/stdin --sout '#rtp{sdp=rtsp://:8554/live}'
 *    - Low latency: ~200ms
 *    - Resolution: 1080p @ 30fps
 *
 * 2. ESP32-CAM
 *    - Built-in MJPEG server
 *    - URL: http://192.168.1.100:81/stream
 *    - Very low cost but higher latency (~500ms)
 *
 * 3. GoPro / DJI Action Camera
 *    - RTMP/RTSP streaming built-in
 *    - Professional quality
 *    - Requires WiFi connection
 *
 * 4. FPV Camera + Video Transmitter
 *    - Analog 5.8GHz transmission
 *    - Requires receiver + HDMI capture card
 *    - Ultra-low latency (<50ms) but needs hardware
 */
