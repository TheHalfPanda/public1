"use client";

import { Delivery } from "@/lib/types";
import { motion, AnimatePresence } from "framer-motion";

interface DeliveryDetailDrawerProps {
  delivery: Delivery | null;
  onClose: () => void;
}

export default function DeliveryDetailDrawer({ delivery, onClose }: DeliveryDetailDrawerProps) {
  if (!delivery) return null;

  const timeSinceOrder = Math.floor(
    (Date.now() - new Date(delivery.timeOrdered).getTime()) / 1000 / 60
  );

  return (
    <AnimatePresence>
      <motion.div
        initial={{ x: "100%" }}
        animate={{ x: 0 }}
        exit={{ x: "100%" }}
        transition={{ type: "spring", damping: 30, stiffness: 300 }}
        className="fixed right-0 top-0 h-full w-[480px] bg-aerly-dark border-l border-white/10 shadow-2xl z-50 overflow-y-auto"
      >
        {/* Header */}
        <div className="sticky top-0 bg-aerly-darker/95 backdrop-blur-sm border-b border-white/10 px-6 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-sm font-semibold tracking-wide uppercase text-white/60">
                DELIVERY DETAILS
              </h2>
              <div className="text-xl font-mono font-bold text-white mt-1">{delivery.id}</div>
            </div>
            <button
              onClick={onClose}
              className="p-2 hover:bg-white/10 rounded-lg transition-colors"
            >
              <svg className="w-5 h-5 text-white/60" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
        </div>

        <div className="p-6 space-y-6">
          {/* Status & Timing */}
          <div className="bg-white/[0.02] border border-white/10 rounded-xl p-4">
            <div className="grid grid-cols-2 gap-4">
              <MetricCard label="TIME ORDERED" value={`${timeSinceOrder}m ago`} />
              <MetricCard label="SLA TARGET" value={`${delivery.sla} min`} />
              {delivery.eta && <MetricCard label="ETA" value={delivery.eta} highlight />}
              {delivery.droneId && <MetricCard label="DRONE ASSIGNED" value={delivery.droneId} />}
            </div>
          </div>

          {/* Payload Info */}
          <div>
            <h3 className="text-xs font-semibold tracking-wider uppercase text-white/60 mb-3">
              PAYLOAD
            </h3>
            <div className="bg-white/[0.02] border border-white/10 rounded-xl p-4 space-y-3">
              <div>
                <div className="text-[10px] text-white/40 uppercase tracking-wider mb-1">Description</div>
                <div className="text-sm text-white">{delivery.payload.description}</div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <div className="text-[10px] text-white/40 uppercase tracking-wider mb-1">Weight</div>
                  <div className="text-sm font-mono text-white">{delivery.payload.weight} kg</div>
                </div>
                <div>
                  <div className="text-[10px] text-white/40 uppercase tracking-wider mb-1">Category</div>
                  <div className="text-sm font-semibold text-aerly-accent uppercase">{delivery.payload.category}</div>
                </div>
              </div>
            </div>
          </div>

          {/* Route */}
          <div>
            <h3 className="text-xs font-semibold tracking-wider uppercase text-white/60 mb-3">
              ROUTE
            </h3>
            <div className="space-y-3">
              <LocationCard
                label="PICKUP"
                name={delivery.pickup.name}
                address={delivery.pickup.address}
                icon="up"
              />
              <div className="flex items-center justify-center">
                <div className="w-px h-8 bg-gradient-to-b from-aerly-accent to-aerly-success" />
              </div>
              <LocationCard
                label="DROPOFF"
                name={delivery.dropoff.name}
                address={delivery.dropoff.address}
                icon="down"
              />
            </div>
          </div>

          {/* Distance */}
          <div className="bg-white/[0.02] border border-white/10 rounded-xl p-4">
            <div className="text-[10px] text-white/40 uppercase tracking-wider mb-2">Distance</div>
            <div className="text-2xl font-mono font-bold text-white">{delivery.distance} km</div>
          </div>

          {/* Economics */}
          <div>
            <h3 className="text-xs font-semibold tracking-wider uppercase text-white/60 mb-3">
              ECONOMICS
            </h3>
            <div className="bg-gradient-to-br from-aerly-accent/5 to-aerly-success/5 border border-aerly-accent/20 rounded-xl p-4 space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <div className="text-[10px] text-white/40 uppercase tracking-wider mb-1">AERLY Cost</div>
                  <div className="text-xl font-mono font-bold text-white">₹{delivery.cost.aerly}</div>
                </div>
                <div>
                  <div className="text-[10px] text-white/40 uppercase tracking-wider mb-1">Bike Courier</div>
                  <div className="text-xl font-mono font-bold text-white/50 line-through">
                    ₹{delivery.cost.bikeCourier}
                  </div>
                </div>
              </div>
              <div className="pt-4 border-t border-white/10">
                <div className="text-[10px] text-white/40 uppercase tracking-wider mb-1">Customer Saves</div>
                <div className="text-2xl font-mono font-bold text-aerly-success">
                  ₹{delivery.cost.savings}
                </div>
                <div className="text-xs text-aerly-success/70 mt-1">
                  {Math.round((delivery.cost.savings / delivery.cost.bikeCourier) * 100)}% cheaper
                </div>
              </div>
            </div>
          </div>

          {/* CO₂ Impact */}
          <div>
            <h3 className="text-xs font-semibold tracking-wider uppercase text-white/60 mb-3">
              ENVIRONMENTAL IMPACT
            </h3>
            <div className="bg-gradient-to-br from-green-500/5 to-emerald-500/5 border border-green-500/20 rounded-xl p-4 space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <div className="text-[10px] text-white/40 uppercase tracking-wider mb-1">AERLY Emissions</div>
                  <div className="text-sm font-mono text-white">{delivery.co2.aerly} kg CO₂</div>
                </div>
                <div>
                  <div className="text-[10px] text-white/40 uppercase tracking-wider mb-1">Bike Courier</div>
                  <div className="text-sm font-mono text-white/50">{delivery.co2.bikeCourier} kg CO₂</div>
                </div>
              </div>
              <div className="pt-4 border-t border-white/10">
                <div className="text-[10px] text-white/40 uppercase tracking-wider mb-1">CO₂ Saved</div>
                <div className="text-2xl font-mono font-bold text-green-400">
                  {delivery.co2.savedKg} kg
                </div>
                <div className="text-xs text-green-400/70 mt-1">
                  {Math.round((delivery.co2.savedKg / delivery.co2.bikeCourier) * 100)}% reduction
                </div>
              </div>
            </div>
          </div>
        </div>
      </motion.div>
    </AnimatePresence>
  );
}

function MetricCard({
  label,
  value,
  highlight = false,
}: {
  label: string;
  value: string;
  highlight?: boolean;
}) {
  return (
    <div>
      <div className="text-[10px] text-white/40 uppercase tracking-wider mb-1">{label}</div>
      <div
        className={`text-sm font-mono font-semibold ${
          highlight ? "text-aerly-accent" : "text-white"
        }`}
      >
        {value}
      </div>
    </div>
  );
}

function LocationCard({
  label,
  name,
  address,
  icon,
}: {
  label: string;
  name: string;
  address: string;
  icon: "up" | "down";
}) {
  return (
    <div className="bg-white/[0.02] border border-white/10 rounded-xl p-4">
      <div className="flex items-start gap-3">
        <div
          className={`p-2 rounded-lg ${
            icon === "up" ? "bg-aerly-accent/10" : "bg-aerly-success/10"
          }`}
        >
          {icon === "up" ? (
            <svg className="w-4 h-4 text-aerly-accent" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 10l7-7m0 0l7 7m-7-7v18" />
            </svg>
          ) : (
            <svg className="w-4 h-4 text-aerly-success" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
            </svg>
          )}
        </div>
        <div className="flex-1">
          <div className="text-[10px] text-white/40 uppercase tracking-wider mb-1">{label}</div>
          <div className="text-sm font-semibold text-white">{name}</div>
          <div className="text-xs text-white/50 mt-1">{address}</div>
        </div>
      </div>
    </div>
  );
}
