import { Delivery } from "../types";

/**
 * In-memory delivery queue shared across API calls
 */

let deliveryQueue: Delivery[] = [];

export function addDelivery(delivery: Delivery): void {
  deliveryQueue.push(delivery);
}

export function getDeliveries(): Delivery[] {
  return deliveryQueue;
}

export function updateDelivery(id: string, updates: Partial<Delivery>): void {
  const index = deliveryQueue.findIndex((d) => d.id === id);
  if (index !== -1) {
    deliveryQueue[index] = { ...deliveryQueue[index], ...updates };
  }
}

export function removeDelivery(id: string): void {
  deliveryQueue = deliveryQueue.filter((d) => d.id !== id);
}
