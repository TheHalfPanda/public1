"use client";

import { useEffect, useState } from "react";
import { Drone, Delivery, Alert, WeatherCondition } from "@/lib/types";
import DroneMap from "@/components/DroneMap";
import FleetStats from "@/components/FleetStats";
import DeliveryList from "@/components/DeliveryList";
import DeliveryDetailDrawer from "@/components/DeliveryDetailDrawer";
import AlertsPanel from "@/components/AlertsPanel";
import WeatherWidget from "@/components/WeatherWidget";
import LaunchControl from "@/components/LaunchControl";
import AIControlPanel from "@/components/AIControlPanel";
import DeliveryCreator, { NewDeliveryRequest } from "@/components/DeliveryCreator";
import HardwarePanel from "@/components/HardwarePanel";
import VideoStream from "@/components/VideoStream";
import AlgorithmVisualizer from "@/components/AlgorithmVisualizer";
import { noFlyZones } from "@/lib/mockData";

export default function MissionControl() {
  const [drones, setDrones] = useState<Drone[]>([]);
  const [deliveries, setDeliveries] = useState<Delivery[]>([]);
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [weather, setWeather] = useState<WeatherCondition | null>(null);
  const [selectedDelivery, setSelectedDelivery] = useState<Delivery | null>(null);
  const [autoAssignments, setAutoAssignments] = useState<number>(0);

  // Poll drones every 2 seconds
  useEffect(() => {
    const fetchDrones = async () => {
      try {
        const res = await fetch("/api/drones");
        const data = await res.json();
        setDrones(data.drones);
        if (data.autoAssignments !== undefined) {
          setAutoAssignments(data.autoAssignments);
        }
      } catch (error) {
        console.error("Failed to fetch drones:", error);
      }
    };

    fetchDrones();
    const interval = setInterval(fetchDrones, 2000);
    return () => clearInterval(interval);
  }, []);

  // Poll deliveries every 2 seconds
  useEffect(() => {
    const fetchDeliveries = async () => {
      try {
        const res = await fetch("/api/deliveries");
        const data = await res.json();
        setDeliveries(data.deliveries);
      } catch (error) {
        console.error("Failed to fetch deliveries:", error);
      }
    };

    fetchDeliveries();
    const interval = setInterval(fetchDeliveries, 2000);
    return () => clearInterval(interval);
  }, []);

  // Poll alerts every 5 seconds
  useEffect(() => {
    const fetchAlerts = async () => {
      try {
        const res = await fetch("/api/alerts");
        const data = await res.json();
        setAlerts(data.alerts);
      } catch (error) {
        console.error("Failed to fetch alerts:", error);
      }
    };

    fetchAlerts();
    const interval = setInterval(fetchAlerts, 5000);
    return () => clearInterval(interval);
  }, []);

  // Poll weather every 10 seconds
  useEffect(() => {
    const fetchWeather = async () => {
      try {
        const res = await fetch("/api/weather");
        const data = await res.json();
        setWeather(data.weather);
      } catch (error) {
        console.error("Failed to fetch weather:", error);
      }
    };

    fetchWeather();
    const interval = setInterval(fetchWeather, 10000);
    return () => clearInterval(interval);
  }, []);

  const handleLaunchMission = async (deliveryId: string) => {
    try {
      const res = await fetch("/api/launch", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ deliveryId }),
      });

      if (!res.ok) {
        throw new Error("Launch failed");
      }

      // Refresh data immediately
      const [dronesRes, deliveriesRes] = await Promise.all([
        fetch("/api/drones"),
        fetch("/api/deliveries"),
      ]);

      const [dronesData, deliveriesData] = await Promise.all([
        dronesRes.json(),
        deliveriesRes.json(),
      ]);

      setDrones(dronesData.drones);
      setDeliveries(deliveriesData.deliveries);
    } catch (error) {
      console.error("Failed to launch mission:", error);
    }
  };

  const handleCreateDelivery = async (request: NewDeliveryRequest) => {
    try {
      const res = await fetch("/api/deliveries/create", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(request),
      });

      if (!res.ok) {
        throw new Error("Failed to create delivery");
      }

      // Refresh deliveries
      const deliveriesRes = await fetch("/api/deliveries");
      const deliveriesData = await deliveriesRes.json();
      setDeliveries(deliveriesData.deliveries);
    } catch (error) {
      console.error("Failed to create delivery:", error);
    }
  };

  const queuedDeliveries = deliveries.filter((d) => d.status === "queued");

  return (
    <div className="min-h-screen bg-aerly-darker text-white">
      {/* Header */}
      <header className="border-b border-white/10 bg-aerly-dark/50 backdrop-blur-sm sticky top-0 z-40">
        <div className="px-8 py-4 flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold tracking-tight">AERLY</h1>
            <p className="text-xs text-white/50 tracking-wide uppercase mt-0.5">
              Mission Control • Hyderabad Pilot
            </p>
          </div>
          <div className="flex items-center gap-6">
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-aerly-success rounded-full animate-pulse" />
              <span className="text-xs font-mono text-white/70">SYSTEMS ACTIVE</span>
            </div>
            <div className="text-xs text-white/50">
              {new Date().toLocaleTimeString("en-IN", { hour12: false })}
            </div>
          </div>
        </div>
      </header>

      {/* Main Dashboard */}
      <div className="p-8">
        {/* AI Control & Fleet Overview */}
        <div className="mb-6 space-y-4">
          <AIControlPanel autoAssignments={autoAssignments} isAIActive={true} />

          <div>
            <h2 className="text-xs font-semibold tracking-wider uppercase text-white/60 mb-4">
              FLEET STATUS
            </h2>
            <FleetStats drones={drones} />
          </div>
        </div>

        {/* Main Grid */}
        <div className="grid grid-cols-12 gap-6">
          {/* Left Column - Map & Alerts */}
          <div className="col-span-8 space-y-6">
            {/* Live Video Feed */}
            <div>
              <h2 className="text-xs font-semibold tracking-wider uppercase text-white/60 mb-4">
                LIVE CAMERA FEED
              </h2>
              <div className="h-[400px]">
                <VideoStream
                  dronePosition={drones[0]?.position}
                  plannedPath={drones[0]?.plannedPath}
                  telemetry={
                    drones[0]
                      ? {
                          altitude: drones[0].altitude,
                          speed: drones[0].speed,
                          battery: drones[0].battery,
                          heading: 0,
                        }
                      : undefined
                  }
                  showOverlay={true}
                />
              </div>
            </div>

            {/* Live Map */}
            <div>
              <h2 className="text-xs font-semibold tracking-wider uppercase text-white/60 mb-4">
                LIVE AIRSPACE
              </h2>
              <div className="h-[400px]">
                <DroneMap drones={drones} />
              </div>
            </div>

            {/* Alerts */}
            <div>
              <h2 className="text-xs font-semibold tracking-wider uppercase text-white/60 mb-4">
                SYSTEM ALERTS
              </h2>
              <AlertsPanel alerts={alerts} />
            </div>

            {/* Launch Control */}
            {queuedDeliveries.length > 0 && (
              <div>
                <h2 className="text-xs font-semibold tracking-wider uppercase text-white/60 mb-4">
                  LAUNCH CONTROL
                </h2>
                <LaunchControl
                  queuedDeliveries={queuedDeliveries}
                  onLaunch={handleLaunchMission}
                />
              </div>
            )}

            {/* Weather */}
            {weather && (
              <div>
                <WeatherWidget weather={weather} />
              </div>
            )}

            {/* Algorithm Visualizer */}
            <div>
              <AlgorithmVisualizer
                start={deliveries[0]?.pickup.coordinates}
                goal={deliveries[0]?.dropoff.coordinates}
                noFlyZones={noFlyZones}
              />
            </div>

            {/* Hardware Bridge */}
            <div>
              <h2 className="text-xs font-semibold tracking-wider uppercase text-white/60 mb-4">
                PHYSICAL DRONE
              </h2>
              <HardwarePanel />
            </div>
          </div>

          {/* Right Column - Deliveries */}
          <div className="col-span-4 space-y-4">
            <div className="sticky top-24 space-y-4">
              {/* Delivery Creator */}
              <DeliveryCreator onCreateDelivery={handleCreateDelivery} />

              {/* Delivery List */}
              <div className="bg-aerly-dark border border-white/10 rounded-xl h-[calc(100vh-20rem)] overflow-hidden">
                <DeliveryList
                  deliveries={deliveries}
                  onSelectDelivery={setSelectedDelivery}
                  selectedDeliveryId={selectedDelivery?.id}
                />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Delivery Detail Drawer */}
      <DeliveryDetailDrawer delivery={selectedDelivery} onClose={() => setSelectedDelivery(null)} />
    </div>
  );
}
