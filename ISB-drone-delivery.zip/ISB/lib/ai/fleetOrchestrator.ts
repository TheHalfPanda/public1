import { Drone, Delivery, NoFlyZone, WeatherCondition, Alert, Coordinates } from "../types";
import {
  calculateDistance,
  estimateFlightTime,
  estimateBatteryConsumption,
} from "./pathfinding";
import { findPathAStar, smoothPath, simplifyPath, AStarResult } from "./astar";

/**
 * Autonomous Fleet Orchestration AI
 * Manages drone assignments, battery optimization, and real-time routing decisions
 */

const BASE_LOCATION: Coordinates = { lat: 17.385, lng: 78.4867 }; // Hyderabad
const CRITICAL_BATTERY_THRESHOLD = 25;
const SAFE_BATTERY_THRESHOLD = 40;
const MIN_BATTERY_FOR_MISSION = 45;
const DRONE_MAX_SPEED = 45; // km/h
const DRONE_CRUISE_SPEED = 40; // km/h

export class FleetOrchestrator {
  private drones: Drone[];
  private deliveries: Delivery[];
  private noFlyZones: NoFlyZone[];
  private weather: WeatherCondition;
  private alerts: Alert[];

  constructor(
    drones: Drone[],
    deliveries: Delivery[],
    noFlyZones: NoFlyZone[],
    weather: WeatherCondition,
    alerts: Alert[]
  ) {
    this.drones = drones;
    this.deliveries = deliveries;
    this.noFlyZones = noFlyZones;
    this.weather = weather;
    this.alerts = alerts;
  }

  /**
   * Main orchestration loop - run every simulation tick
   */
  public tick(): {
    drones: Drone[];
    deliveries: Delivery[];
    alerts: Alert[];
    autoAssignments: number;
  } {
    let autoAssignments = 0;

    // Step 1: Battery management - force low battery drones to return
    this.manageBatteryStates();

    // Step 2: Update positions for active drones
    this.updateDronePositions();

    // Step 3: Check for completed deliveries
    this.checkCompletedDeliveries();

    // Step 4: Check for returned drones
    this.checkReturnedDrones();

    // Step 5: Auto-assign queued deliveries to idle drones
    autoAssignments = this.autoAssignDeliveries();

    // Step 6: Update ETAs for in-flight deliveries
    this.updateDeliveryETAs();

    // Step 7: Generate alerts for critical situations
    this.generateAlerts();

    return {
      drones: this.drones,
      deliveries: this.deliveries,
      alerts: this.alerts,
      autoAssignments,
    };
  }

  /**
   * Force low battery drones to return to base
   */
  private manageBatteryStates(): void {
    for (const drone of this.drones) {
      if (drone.battery <= CRITICAL_BATTERY_THRESHOLD && drone.status !== "charging") {
        // Critical battery - initiate return immediately
        if (drone.status === "en_route" && drone.assignedDelivery) {
          // Abort mission, reassign delivery
          const delivery = this.deliveries.find((d) => d.id === drone.assignedDelivery);
          if (delivery) {
            delivery.status = "queued";
            delivery.droneId = null;
            delivery.eta = null;
          }
        }

        drone.status = "returning";
        drone.assignedDelivery = undefined;
        drone.payload = undefined;
        drone.eta = undefined;
      } else if (
        drone.battery <= SAFE_BATTERY_THRESHOLD &&
        drone.status === "en_route" &&
        drone.assignedDelivery
      ) {
        // Check if drone has enough battery to complete mission + return
        const delivery = this.deliveries.find((d) => d.id === drone.assignedDelivery);
        if (delivery) {
          const distanceToGoal = calculateDistance(drone.position, delivery.dropoff.coordinates);
          const distanceToBase = calculateDistance(delivery.dropoff.coordinates, BASE_LOCATION);
          const totalDistance = distanceToGoal + distanceToBase;

          const requiredBattery = estimateBatteryConsumption(
            totalDistance,
            delivery.payload.weight,
            this.weather.windSpeed
          );

          if (drone.battery < requiredBattery + 10) {
            // Not enough battery - abort and return
            delivery.status = "queued";
            delivery.droneId = null;
            delivery.eta = null;

            drone.status = "returning";
            drone.assignedDelivery = undefined;
            drone.payload = undefined;
            drone.eta = undefined;
          }
        }
      }
    }
  }

  /**
   * Update drone positions based on their current route
   */
  private updateDronePositions(): void {
    for (const drone of this.drones) {
      if (drone.status === "en_route" && drone.assignedDelivery) {
        const delivery = this.deliveries.find((d) => d.id === drone.assignedDelivery);
        if (!delivery) continue;

        // Compute A* path if not already planned
        if (!drone.plannedPath || drone.plannedPath.length === 0) {
          const astarResult = findPathAStar(
            drone.position,
            delivery.dropoff.coordinates,
            this.noFlyZones
          );

          // Smooth and simplify the path for realistic flight
          const smoothedPath = smoothPath(astarResult.path, 2);
          drone.plannedPath = simplifyPath(smoothedPath, 0.0002);
          drone.currentWaypointIndex = 0;

          console.log(
            `A* computed path for ${drone.callsign}: ${drone.plannedPath.length} waypoints, ${astarResult.nodesExplored} nodes explored`
          );
        }

        // Follow planned path
        if (drone.plannedPath && drone.currentWaypointIndex !== undefined) {
          const nextWaypoint = drone.plannedPath[drone.currentWaypointIndex + 1];

          if (!nextWaypoint) {
            // Reached final waypoint
            drone.position = drone.plannedPath[drone.plannedPath.length - 1];
          } else {
            const distance = calculateDistance(drone.position, nextWaypoint);
            const moveDistance = (DRONE_CRUISE_SPEED / 3600) * 2; // km moved in 2 seconds

            if (distance < moveDistance * 0.5) {
              // Reached waypoint, move to next
              drone.currentWaypointIndex++;
              drone.position = nextWaypoint;
            } else {
              // Move toward waypoint
              const ratio = moveDistance / distance;
              drone.position = {
                lat: drone.position.lat + (nextWaypoint.lat - drone.position.lat) * ratio,
                lng: drone.position.lng + (nextWaypoint.lng - drone.position.lng) * ratio,
              };
            }
          }
        }

        // Update battery (4% per km baseline)
        const moveDistance = (DRONE_CRUISE_SPEED / 3600) * 2;
        const batteryDrain = estimateBatteryConsumption(
          moveDistance,
          delivery.payload.weight,
          this.weather.windSpeed
        );
        drone.battery = Math.max(0, drone.battery - batteryDrain);

        // Update speed with slight variance
        drone.speed = DRONE_CRUISE_SPEED + (Math.random() - 0.5) * 4;

        // Update temperature (increases with flight time)
        drone.temperature = Math.min(50, 38 + (100 - drone.battery) * 0.12);

        // Update altitude (cruise altitude with slight variance)
        drone.altitude = 85 + Math.sin(Date.now() / 1000) * 8;
      } else if (drone.status === "returning") {
        // Move toward base
        const distance = calculateDistance(drone.position, BASE_LOCATION);
        const moveDistance = (DRONE_CRUISE_SPEED / 3600) * 2;

        if (distance < 0.05) {
          // Reached base
          drone.position = BASE_LOCATION;
          drone.status = "charging";
          drone.speed = 0;
          drone.altitude = 0;
        } else {
          const ratio = Math.min(1, moveDistance / distance);
          drone.position = {
            lat: drone.position.lat + (BASE_LOCATION.lat - drone.position.lat) * ratio,
            lng: drone.position.lng + (BASE_LOCATION.lng - drone.position.lng) * ratio,
          };

          drone.battery = Math.max(0, drone.battery - 0.15);
          drone.speed = DRONE_CRUISE_SPEED - 5;
          drone.altitude = 75 + Math.sin(Date.now() / 1000) * 5;
        }
      } else if (drone.status === "charging") {
        // Charge at 2.5% per tick (full charge in ~40 ticks = 80 seconds)
        drone.battery = Math.min(100, drone.battery + 2.5);
        drone.temperature = Math.max(35, drone.temperature - 0.5);

        if (drone.battery >= 98) {
          drone.status = "idle";
        }
      }
    }
  }

  /**
   * Check if any deliveries have been completed
   */
  private checkCompletedDeliveries(): void {
    for (const delivery of this.deliveries) {
      if (delivery.status === "in_flight" && delivery.droneId) {
        const drone = this.drones.find((d) => d.id === delivery.droneId);
        if (!drone) continue;

        const distance = calculateDistance(drone.position, delivery.dropoff.coordinates);

        if (distance < 0.02) {
          // Delivery complete
          delivery.status = "delivered";
          delivery.timeDelivered = new Date().toISOString();
          delivery.eta = null;

          // Drone starts returning
          drone.status = "returning";
          drone.assignedDelivery = undefined;
          drone.payload = undefined;
          drone.eta = undefined;
        }
      }
    }
  }

  /**
   * Check if returning drones have reached base
   */
  private checkReturnedDrones(): void {
    for (const drone of this.drones) {
      if (drone.status === "returning") {
        const distance = calculateDistance(drone.position, BASE_LOCATION);
        if (distance < 0.05) {
          drone.status = "charging";
          drone.position = BASE_LOCATION;
          drone.speed = 0;
          drone.altitude = 0;
        }
      }
    }
  }

  /**
   * Auto-assign queued deliveries to available drones
   */
  private autoAssignDeliveries(): number {
    const queuedDeliveries = this.deliveries.filter((d) => d.status === "queued");
    const availableDrones = this.drones.filter(
      (d) => d.status === "idle" && d.battery >= MIN_BATTERY_FOR_MISSION
    );

    if (queuedDeliveries.length === 0 || availableDrones.length === 0) {
      return 0;
    }

    let assignments = 0;

    // Sort deliveries by priority (medical > pharmacy > urgent > high-value)
    const priorityOrder = { medical: 4, pharmacy: 3, urgent: 2, "high-value": 1 };
    queuedDeliveries.sort((a, b) => {
      return priorityOrder[b.payload.category] - priorityOrder[a.payload.category];
    });

    for (const delivery of queuedDeliveries) {
      if (availableDrones.length === 0) break;

      // Find closest drone with sufficient battery
      let bestDrone: Drone | null = null;
      let minDistance = Infinity;

      for (const drone of availableDrones) {
        const distance = calculateDistance(BASE_LOCATION, delivery.pickup.coordinates);
        const totalDistance =
          distance +
          delivery.distance +
          calculateDistance(delivery.dropoff.coordinates, BASE_LOCATION);

        const requiredBattery = estimateBatteryConsumption(
          totalDistance,
          delivery.payload.weight,
          this.weather.windSpeed
        );

        if (drone.battery >= requiredBattery + 15 && distance < minDistance) {
          bestDrone = drone;
          minDistance = distance;
        }
      }

      if (bestDrone) {
        // Assign delivery
        const flightTime = estimateFlightTime(delivery.distance);
        const eta = `${Math.floor(flightTime)}m ${Math.round((flightTime % 1) * 60)}s`;

        bestDrone.status = "en_route";
        bestDrone.assignedDelivery = delivery.id;
        bestDrone.eta = eta;
        bestDrone.payload = `${delivery.payload.description} (${delivery.payload.weight} kg)`;
        bestDrone.position = delivery.pickup.coordinates;
        bestDrone.plannedPath = undefined; // Will be computed on next tick
        bestDrone.currentWaypointIndex = undefined;

        delivery.status = "assigned";
        delivery.droneId = bestDrone.id;
        delivery.eta = eta;

        // Transition to in_flight after brief delay
        setTimeout(() => {
          delivery.status = "in_flight";
        }, 1000);

        // Remove from available pool
        availableDrones.splice(availableDrones.indexOf(bestDrone), 1);
        assignments++;
      }
    }

    return assignments;
  }

  /**
   * Update ETAs for in-flight deliveries
   */
  private updateDeliveryETAs(): void {
    for (const delivery of this.deliveries) {
      if (delivery.status === "in_flight" && delivery.droneId && delivery.eta) {
        const drone = this.drones.find((d) => d.id === delivery.droneId);
        if (!drone) continue;

        const distance = calculateDistance(drone.position, delivery.dropoff.coordinates);
        const timeRemaining = estimateFlightTime(distance);

        const minutes = Math.floor(timeRemaining);
        const seconds = Math.round((timeRemaining % 1) * 60);

        delivery.eta = `${minutes}m ${seconds}s`;
        drone.eta = `${minutes}m ${seconds}s`;
      }
    }
  }

  /**
   * Generate alerts based on current fleet state
   */
  private generateAlerts(): void {
    const now = new Date().toISOString();

    // Clear old resolved alerts
    this.alerts = this.alerts.filter((a) => !a.resolved);

    // Battery alerts
    for (const drone of this.drones) {
      const existingAlert = this.alerts.find(
        (a) => a.droneId === drone.id && a.category === "battery"
      );

      if (drone.battery <= CRITICAL_BATTERY_THRESHOLD && !existingAlert) {
        this.alerts.push({
          id: `ALT-${Date.now()}-${drone.id}`,
          severity: "critical",
          category: "battery",
          message: `${drone.callsign} battery critical at ${Math.round(drone.battery)}% - emergency landing protocol active`,
          droneId: drone.id,
          timestamp: now,
          resolved: false,
        });
      } else if (drone.battery <= SAFE_BATTERY_THRESHOLD && !existingAlert) {
        this.alerts.push({
          id: `ALT-${Date.now()}-${drone.id}`,
          severity: "warning",
          category: "battery",
          message: `${drone.callsign} battery below ${SAFE_BATTERY_THRESHOLD}% - returning to base`,
          droneId: drone.id,
          timestamp: now,
          resolved: false,
        });
      } else if (drone.battery > SAFE_BATTERY_THRESHOLD && existingAlert) {
        existingAlert.resolved = true;
      }
    }

    // Weather alerts
    if (this.weather.windSpeed > 20) {
      const existingWeatherAlert = this.alerts.find(
        (a) => a.category === "weather" && !a.resolved
      );

      if (!existingWeatherAlert) {
        this.alerts.push({
          id: `ALT-${Date.now()}-WEATHER`,
          severity: "warning",
          category: "weather",
          message: `High wind conditions detected: ${Math.round(this.weather.windSpeed)} km/h - monitoring all active flights`,
          timestamp: now,
          resolved: false,
        });
      }
    }

    // Airspace alerts for active no-fly zones
    const activeNoFlyZones = this.noFlyZones.filter((z) => z.active);
    for (const zone of activeNoFlyZones) {
      const existingZoneAlert = this.alerts.find(
        (a) => a.category === "airspace" && a.message.includes(zone.name)
      );

      if (!existingZoneAlert) {
        this.alerts.push({
          id: `ALT-${Date.now()}-${zone.id}`,
          severity: "info",
          category: "airspace",
          message: `No-fly zone active: ${zone.name} - ${zone.reason}`,
          timestamp: now,
          resolved: false,
        });
      }
    }
  }

  /**
   * Manual delivery assignment (from UI)
   */
  public assignDelivery(deliveryId: string): { success: boolean; error?: string } {
    const delivery = this.deliveries.find((d) => d.id === deliveryId);
    if (!delivery || delivery.status !== "queued") {
      return { success: false, error: "Delivery not found or already assigned" };
    }

    const availableDrone = this.drones.find(
      (d) => d.status === "idle" && d.battery >= MIN_BATTERY_FOR_MISSION
    );

    if (!availableDrone) {
      return { success: false, error: "No drones available" };
    }

    const flightTime = estimateFlightTime(delivery.distance);
    const eta = `${Math.floor(flightTime)}m ${Math.round((flightTime % 1) * 60)}s`;

    availableDrone.status = "en_route";
    availableDrone.assignedDelivery = delivery.id;
    availableDrone.eta = eta;
    availableDrone.payload = `${delivery.payload.description} (${delivery.payload.weight} kg)`;
    availableDrone.position = delivery.pickup.coordinates;
    availableDrone.plannedPath = undefined; // Will be computed on next tick
    availableDrone.currentWaypointIndex = undefined;

    delivery.status = "assigned";
    delivery.droneId = availableDrone.id;
    delivery.eta = eta;

    setTimeout(() => {
      delivery.status = "in_flight";
    }, 1000);

    return { success: true };
  }
}
