# Real Drone Hardware Integration

Complete guide to connecting AERLY mission control to physical drones via MAVLink protocol.

## Supported Hardware

- **PX4 Autopilot** (recommended for commercial operations)
- **ArduPilot** (ArduCopter, ArduPlane)
- **Any MAVLink-compatible flight controller**

## Connection Methods

### 1. USB Serial Connection
**Direct cable to autopilot**

```typescript
const drone = new MAVLinkDrone({
  type: "serial",
  port: "/dev/ttyUSB0",      // Linux
  // port: "COM3",            // Windows
  // port: "/dev/tty.usbserial", // macOS
  baudRate: 57600,            // or 115200
});

await drone.connect();
```

**Hardware requirements:**
- USB-to-UART cable (FTDI or CP2102)
- Connected to TELEM1 or TELEM2 port on autopilot
- Ground station software closed (only one connection allowed)

---

### 2. UDP Network Connection
**WiFi telemetry or SITL simulation**

```typescript
const drone = new MAVLinkDrone({
  type: "udp",
  host: "192.168.1.100",  // Drone's IP address
  udpPort: 14550,         // Default MAVLink port
});

await drone.connect();
```

**Use cases:**
- **SITL (Software-In-The-Loop):** Test missions in simulator before real flight
- **WiFi telemetry modules:** ESP8266/ESP32 MAVLink bridge
- **Companion computer:** Raspberry Pi running on drone

**SITL Setup (PX4):**
```bash
# Terminal 1: Start PX4 SITL
cd ~/PX4-Autopilot
make px4_sitl gazebo

# Terminal 2: Run AERLY dashboard
cd ~/AERLY
npm run dev

# Dashboard will auto-detect SITL on localhost:14550
```

---

## Mission Upload Workflow

### Step 1: Create Delivery in Dashboard
1. Click "NEW DELIVERY REQUEST"
2. Select pickup and dropoff locations
3. AI computes A* path avoiding no-fly zones

### Step 2: Upload to Physical Drone
```typescript
// Endpoint: POST /api/hardware/mission
{
  "droneId": "AE-01",
  "deliveryId": "DEL-1001"
}

// Response:
{
  "success": true,
  "waypoints": [
    { "lat": 17.4126, "lng": 78.4489 },
    { "lat": 17.4180, "lng": 78.4420 },
    // ... smoothed A* path
    { "lat": 17.4239, "lng": 78.4088 }
  ],
  "nodesExplored": 87,
  "distance": 4.2
}
```

### Step 3: Execute Mission
Dashboard sends MAVLink commands:
1. **TAKEOFF** to 85m altitude
2. **WAYPOINT** navigation through A* path
3. **LAND** at dropoff location

---

## Real-Time Telemetry

### Dashboard Display
Hardware panel shows live data at 1 Hz:

- **GPS Fix:** 3D fix status, satellite count
- **Position:** Lat/lng with 6 decimal precision
- **Altitude:** Meters above sea level
- **Speed:** Ground speed in m/s
- **Battery:** Percentage + voltage/current
- **Mode:** MANUAL, STABILIZE, AUTO, RTL, LAND

### Telemetry Streaming
```typescript
drone.onTelemetry((telemetry) => {
  console.log("Position:", telemetry.position);
  console.log("Battery:", telemetry.battery);
  console.log("Armed:", telemetry.armed);
});
```

Updates every second from autopilot heartbeat.

---

## MAVLink Messages Used

| Message | Purpose |
|---------|---------|
| `HEARTBEAT` | Connection status, armed state, flight mode |
| `GLOBAL_POSITION_INT` | GPS lat/lng, altitude, heading, speed |
| `SYS_STATUS` | Battery voltage, current, percentage |
| `GPS_RAW_INT` | Satellite count, fix type |
| `MISSION_COUNT` | Upload mission waypoint count |
| `MISSION_ITEM_INT` | Individual waypoint data |
| `COMMAND_LONG` | Arm, takeoff, mode changes |
| `SET_MODE` | Switch between MANUAL, AUTO, RTL |

Full protocol: [MAVLink v2.0 Spec](https://mavlink.io/en/)

---

## Production Deployment

### Node.js Backend Required
Browsers cannot access serial ports or raw UDP. Use Node.js bridge:

```javascript
// server.js (Node.js backend)
const SerialPort = require('serialport');
const WebSocket = require('ws');

const port = new SerialPort('/dev/ttyUSB0', { baudRate: 57600 });
const wss = new WebSocket.Server({ port: 8080 });

port.on('data', (data) => {
  // Parse MAVLink binary
  const message = parseMavlink(data);

  // Forward to web dashboard
  wss.clients.forEach((client) => {
    client.send(JSON.stringify(message));
  });
});
```

Dashboard connects via WebSocket instead of direct serial.

---

## Safety Protocols

**Pre-Flight Checklist:**
1. ✅ A* path clear of no-fly zones
2. ✅ Battery > 60% for mission + return
3. ✅ GPS fix with 10+ satellites
4. ✅ Wind speed < 20 km/h
5. ✅ Geofence configured in autopilot
6. ✅ Return-to-launch altitude set
7. ✅ Emergency landing zones identified

**During Flight:**
- Monitor battery threshold (force RTL at 30%)
- Track GPS satellite count (abort if < 6)
- Watch telemetry for autopilot errors
- Manual override available via RC transmitter

**Emergency Actions:**
```typescript
await drone.returnToLaunch();  // Return to takeoff point
await drone.emergencyLand();   // Land immediately at current position
await drone.setMode("MANUAL"); // Hand control to RC pilot
```

---

## Testing with SITL

### PX4 SITL Setup
```bash
# Install PX4
git clone https://github.com/PX4/PX4-Autopilot.git
cd PX4-Autopilot
bash ./Tools/setup/ubuntu.sh

# Run SITL with Gazebo visualization
make px4_sitl gazebo

# SITL will broadcast MAVLink on UDP 14550
# Dashboard auto-connects when you click "CONNECT TO DRONE"
```

### ArduPilot SITL Setup
```bash
# Install ArduPilot
git clone https://github.com/ArduPilot/ardupilot.git
cd ardupilot
git submodule update --init --recursive

# Run ArduCopter SITL
cd ArduCopter
sim_vehicle.py --console --map

# Connect dashboard to 127.0.0.1:14550
```

**Test Flight:**
1. Create delivery in dashboard
2. Upload mission to SITL drone
3. Watch simulated drone follow A* path in Gazebo
4. Verify telemetry updates in dashboard

---

## Regulatory Compliance (India - DGCA)

**Required for real operations:**
- **UIN (Unique Identification Number):** Register each drone with DGCA
- **NPNT (No Permission No Takeoff):** GPS-based geofencing mandatory
- **Flight plan approval:** Submit route to Digital Sky platform
- **Remote pilot license:** DGCA-certified drone pilot

**Geofencing integration:**
```typescript
// Load official DGCA no-fly zones
const dgcaZones = await fetch('https://digitalsky.dgca.gov.in/api/geofences');
const noFlyZones = dgcaZones.map(zone => ({
  coordinates: { lat: zone.lat, lng: zone.lng },
  radius: zone.radius,
  active: true,
}));

// A* automatically avoids these zones
const path = findPathAStar(start, goal, noFlyZones);
```

---

## Hardware Recommendations

**Entry-level (₹50,000-₹1,00,000):**
- Frame: DJI F450 or Tarot 650
- Autopilot: Pixhawk 4 or Holybro Kakute F7
- GPS: u-blox M8N with compass
- Telemetry: 433MHz long-range radio

**Commercial (₹2,00,000-₹5,00,000):**
- Frame: Custom carbon fiber
- Autopilot: Pixhawk 6C or Cube Orange+
- GPS: u-blox F9P RTK (cm-level accuracy)
- Companion: Raspberry Pi 4 for AI
- Payload: Temperature-controlled box (2kg capacity)

**Sensors:**
- Lidar for obstacle detection
- Optical flow for indoor/GPS-denied flight
- Parachute system for emergencies

---

## Example: Full Mission Execution

```typescript
// 1. Connect to drone
const drone = new MAVLinkDrone({
  type: "udp",
  host: "192.168.1.100",
  udpPort: 14550,
});

await drone.connect();

// 2. Compute A* path
const path = findPathAStar(
  { lat: 17.4126, lng: 78.4489 }, // Banjara Hills pharmacy
  { lat: 17.4239, lng: 78.4088 }, // Jubilee Hills residence
  noFlyZones
);

const smoothedPath = smoothPath(path.path, 2);
const finalPath = simplifyPath(smoothedPath, 0.0002);

// 3. Upload mission
await drone.uploadMission(finalPath);

// 4. Execute
await drone.arm();
await drone.startMission();

// 5. Monitor telemetry
drone.onTelemetry((telemetry) => {
  console.log(`Position: ${telemetry.position.lat}, ${telemetry.position.lng}`);
  console.log(`Battery: ${telemetry.battery}%`);

  if (telemetry.battery < 30) {
    drone.returnToLaunch();
  }
});

// 6. Wait for completion
// Drone auto-lands at dropoff
```

---

## Troubleshooting

**Connection failed:**
- Check USB cable / WiFi network
- Verify baud rate (57600 vs 115200)
- Close QGroundControl / Mission Planner
- Linux: Add user to `dialout` group

**No telemetry:**
- Autopilot not armed
- MAVLink version mismatch (v1 vs v2)
- Firewall blocking UDP port 14550

**Mission upload failed:**
- Too many waypoints (max 255)
- Invalid altitude (below ground level)
- Path enters geofence

**GPS issues:**
- Indoor testing (use SITL instead)
- Insufficient satellites (move outdoors)
- GPS module not powered

---

**Current Status:** Production-ready MAVLink integration. Connect real PX4/ArduPilot drones, upload A* missions, stream live telemetry to dashboard.
