import { NextResponse } from "next/server";
import { getOrchestrator } from "@/lib/ai/orchestratorInstance";

export async function GET() {
  const orchestrator = getOrchestrator();
  const result = orchestrator.tick();

  return NextResponse.json({
    drones: result.drones,
    autoAssignments: result.autoAssignments,
  });
}
