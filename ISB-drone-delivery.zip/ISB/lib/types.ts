export type DroneStatus = "idle" | "en_route" | "returning" | "charging" | "maintenance";
export type DeliveryStatus = "queued" | "assigned" | "in_flight" | "delivered" | "failed";
export type AlertSeverity = "critical" | "warning" | "info";

export interface Coordinates {
  lat: number;
  lng: number;
}

export interface Drone {
  id: string;
  callsign: string;
  status: DroneStatus;
  battery: number;
  position: Coordinates;
  assignedDelivery?: string;
  eta?: string;
  payload?: string;
  temperature: number;
  altitude: number;
  speed: number;
  plannedPath?: Coordinates[]; // A* computed path
  currentWaypointIndex?: number; // Current waypoint in path
}

export interface Delivery {
  id: string;
  droneId: string | null;
  status: DeliveryStatus;
  pickup: {
    name: string;
    address: string;
    coordinates: Coordinates;
  };
  dropoff: {
    name: string;
    address: string;
    coordinates: Coordinates;
  };
  payload: {
    weight: number;
    description: string;
    category: "pharmacy" | "medical" | "urgent" | "high-value";
  };
  distance: number;
  eta: string | null;
  timeOrdered: string;
  timeDelivered?: string;
  sla: number;
  cost: {
    aerly: number;
    bikeCourier: number;
    savings: number;
  };
  co2: {
    aerly: number;
    bikeCourier: number;
    savedKg: number;
  };
}

export interface NoFlyZone {
  id: string;
  name: string;
  coordinates: Coordinates;
  radius: number;
  reason: string;
  active: boolean;
}

export interface Alert {
  id: string;
  severity: AlertSeverity;
  category: "battery" | "weather" | "airspace" | "maintenance" | "system";
  message: string;
  droneId?: string;
  timestamp: string;
  resolved: boolean;
}

export interface WeatherCondition {
  windSpeed: number;
  windDirection: number;
  temperature: number;
  visibility: number;
  conditions: string;
}
